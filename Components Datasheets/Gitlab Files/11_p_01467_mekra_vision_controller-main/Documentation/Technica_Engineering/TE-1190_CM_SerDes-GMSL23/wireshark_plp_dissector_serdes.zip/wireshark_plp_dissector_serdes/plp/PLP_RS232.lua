-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


do
	-- Create a new dissector
	RS232_PROTO = Proto("PLP_RS232", "PLP RS232")
	const_rs232_MsgType = 0x0010
	
	-- Create the protocol fields
	local f = RS232_PROTO.fields
	
	f.payload = ProtoField.bytes ("plp_rs232.payload", "Payload", base.NONE)

	

	local plp_rs232_table = DissectorTable.new("plp_rs232", "plp_rs232")

	-- The dissector function
	function RS232_PROTO.dissector (buffer, pinfo, tree)
		


		-- Adding fields to the tree
		local rs232_tree = tree:add (RS232_PROTO, buffer())
		
		rs232_tree:add(f.payload, buffer:range(0, buffer:len()))
		
		
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_rs232_MsgType, RS232_PROTO)
end