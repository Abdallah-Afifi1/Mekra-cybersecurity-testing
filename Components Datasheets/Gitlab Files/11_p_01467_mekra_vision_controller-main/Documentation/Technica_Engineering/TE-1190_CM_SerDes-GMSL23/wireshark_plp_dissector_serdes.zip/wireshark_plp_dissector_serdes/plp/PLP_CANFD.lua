-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["plp_can_id"] = 1,
  ["plp_can"] = 52,
  ["plp_can_bit_length"] = 40
}

do
	-- Create a new dissector
	CANFD_PROTO = Proto("PLP_CANFD", "PLP_CANFD")
	const_canFD_MsgType = 0x0003
	
	-- Create the protocol fields
	local f = CANFD_PROTO.fields

	f.identifier_11 = ProtoField.uint32("plp_can.identifier_11", _ljust("Identifier", al_f["plp_can_id"]), base.HEX, nil, 0x000007FF, "Identifier")
	f.identifier_29 = ProtoField.uint32("plp_can.identifier_29", _ljust("Identifier", al_f["plp_can_id"]), base.HEX, nil, 0x1FFFFFFF, "Identifier")

	f.ident_flags = ProtoField.bool ("plp_can.ident_flags", _ljust("ID Bitlength", al_f["plp_can_bit_length"]), 8, {"29-bit", "11-bit"}, 0x80, "ID Bitlength")
	f.length = ProtoField.uint8 ("plp_can.length", _ljust("Length", al_f["plp_can"]), base.DEC)
	f.payload = ProtoField.bytes ("plp_can.payload", _ljust("Payload", al_f["plp_can"]))
	
	local plp_can_table = DissectorTable.new("plp_canfd", "plp_canfd")


	-- The dissector function
	function CANFD_PROTO.dissector (pointer_to_dataflags, pinfo, tree)
        -- first of all extract data_flags
        O_DATA_FLAGS = 0
        DATAFLAGS_LENGTH = 2
		local vd_flags_val = pointer_to_dataflags:range(O_DATA_FLAGS, DATAFLAGS_LENGTH):uint()
        
        local error_frame_bit = get_error_frame_bit(vd_flags_val)
        local esi_frame_bit = get_esi_frame_bit(vd_flags_val)
        
        -- After extracting the needed info from dataflags
        -- we restore the pointer like usual.
        buffer = pointer_to_dataflags(DATAFLAGS_LENGTH,pointer_to_dataflags:len() - DATAFLAGS_LENGTH):tvb()
		    
		-- Adding fields to the tree
		local can_tree = tree:add (CANFD_PROTO, buffer())

		if (error_frame_bit == 1) then
			can_tree:append_text(" [Error Frame]")	
		else
			identifier_high_bits = buffer(0, 1):uint()
	        local canid_val = nil
			if (bit.band(identifier_high_bits, 0x80) == 0) then -- 11-bit identifier
				can_tree:add(f.identifier_11, buffer:range(0,4))
	            canid_val = bit.band(buffer:range(0,4):uint(),0x000007FF)
			else 												-- 29-bit identifier
				can_tree:add(f.identifier_29, buffer:range(0,4))
	            canid_val = bit.band(buffer:range(0,4):uint(),0x1FFFFFFF)
			end	
		
			can_tree:add(f.ident_flags, buffer:range(0,1))
				
			length_can = buffer(4, 1):uint()
			can_tree:add(f.length, buffer:range(4,1), length_can)
			
            -- dissect the payload just in case we are not dealing with a remote frame.
            if (esi_frame_bit == 0) then
                can_tree:add(f.payload, buffer:range(5,length_can))
            else
                can_tree:append_text(" [Error Passive]")
                can_tree:add(f.payload, buffer:range(5,length_can))
            end
		end
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_canFD_MsgType, CANFD_PROTO)
end

-- Extract the esi_frame bit from the data_flags
get_esi_frame_bit = function (data_flags)
	DATA_FLAGS_SHIFT_UNIT = 1		
	return get_bit_from_data_flags(data_flags, DATA_FLAGS_SHIFT_UNIT)
end 

-- Extract the error bit from the data_flags
get_error_frame_bit = function (data_flags)
	DATA_FLAGS_SHIFT_UNIT = 3	
	return get_bit_from_data_flags(data_flags, DATA_FLAGS_SHIFT_UNIT)
end 

-- Extract one bit from the data_flags.
-- shift_unit says how many times we should shift to the right.
-- the least significan bit will be returned.
get_bit_from_data_flags = function(data_flags, shift_unit)
    -- least significant bit.
    DATA_FLAGS_MASK_UNIT = 0x1
    extracted_bit = bit32.band(bit32.rshift(data_flags, shift_unit), DATA_FLAGS_MASK_UNIT)
    return extracted_bit

end