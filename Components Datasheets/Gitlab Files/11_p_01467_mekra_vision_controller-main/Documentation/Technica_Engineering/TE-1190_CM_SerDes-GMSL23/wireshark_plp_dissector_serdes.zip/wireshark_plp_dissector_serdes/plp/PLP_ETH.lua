-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------

do
	-- Create a new dissector
	ETH_PROTO = Proto("PLP_ETH", "PLP Ethernet")
	const_eth_MsgType = 0x0080
	const_eth_tapi1 = 0x0200
	const_eth_tapi2 = 0x0201
	const_eth_tapi3 = 0x0202 
	
	


	-- The dissector function
	function ETH_PROTO.dissector (buffer, pinfo, tree)
		-- Adding fields to the tree
		local eth_tree = tree:add (ETH_PROTO, buffer())
		
		
		local success, eth_dissector = pcall(Dissector.get, "eth_withfcs")
		if not success or not eth_dissector then
			eth_dissector = Dissector.get("eth")
		end

		eth_dissector:call(buffer, pinfo, eth_tree)
	
		
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_eth_MsgType, ETH_PROTO)
	plp_table:add(const_eth_tapi1, ETH_PROTO)
	plp_table:add(const_eth_tapi2, ETH_PROTO)
	plp_table:add(const_eth_tapi3, ETH_PROTO)
end