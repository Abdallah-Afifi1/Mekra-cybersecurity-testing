-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


local ENUM_VENDOR_ID_TYPE = {
	[0x04] = "AeD",
	[0x08] = "Conti",
	[0x0C] = "Technica",
	[0x10] = "ViGEM",
	[0x14] = "X2E",
	[0x20] = "Magna",
	[0x22] = "Valeo",
	[0x24] = "Aptiv"
}

local PLP_PROBE_ID = {
	[48] = "LIN Combo 0 - 10.104.3.48",
	[49] = "LIN Combo 1 - 10.104.3.49",
	[50] = "LIN Combo 2 - 10.104.3.50",
	[51] = "LIN Combo 3 - 10.104.3.51",
	[52] = "LIN Combo 4 - 10.104.3.52",
	[53] = "LIN Combo 5 - 10.104.3.53",
	[54] = "LIN Combo 6 - 10.104.3.54",
	[55] = "LIN Combo 7 - 10.104.3.55",
	[56] = "LIN Combo 8 - 10.104.3.56",
	[57] = "LIN Combo 9 - 10.104.3.57",
	[58] = "LIN Combo 10 - 10.104.3.58",
	[59] = "LIN Combo 11 - 10.104.3.59",
	[60] = "LIN Combo 12 - 10.104.3.60",
	[61] = "LIN Combo 13 - 10.104.3.61",
	[62] = "LIN Combo 14 - 10.104.3.62",
	[63] = "LIN Combo 15 - 10.104.3.63",
	[64] = "CAN Combo 0 - 10.104.3.64",
	[65] = "CAN Combo 1 - 10.104.3.65",
	[66] = "CAN Combo 2 - 10.104.3.66",
	[67] = "CAN Combo 3 - 10.104.3.67",
	[68] = "CAN Combo 4 - 10.104.3.68",
	[69] = "CAN Combo 5 - 10.104.3.69",
	[70] = "CAN Combo 6 - 10.104.3.70",
	[71] = "CAN Combo 7 - 10.104.3.71",
	[72] = "CAN Combo 8 - 10.104.3.72",
	[73] = "CAN Combo 9 - 10.104.3.73",
	[74] = "CAN Combo 10 - 10.104.3.74",
	[75] = "CAN Combo 11 - 10.104.3.75",
	[76] = "CAN Combo 12 - 10.104.3.76",
	[77] = "CAN Combo 13 - 10.104.3.77",
	[78] = "CAN Combo 14 - 10.104.3.78",
	[79] = "CAN Combo 15 - 10.104.3.79",
	[96] = "100 High 0 - 10.104.3.96",
	[97] = "100 High 1 - 10.104.3.97",
	[98] = "100 High 2 - 10.104.3.98",
	[99] = "100 High 3 - 10.104.3.99",
	[100] = "100 High 4 - 10.104.3.100",
	[101] = "100 High 5 - 10.104.3.101",
	[102] = "100 High 6 - 10.104.3.102",
	[103] = "100 High 7 - 10.104.3.103",
	[104] = "100 High 8 - 10.104.3.104",
	[105] = "100 High 9 - 10.104.3.105",
	[106] = "100 High 10 - 10.104.3.106",
	[107] = "100 High 11 - 10.104.3.107",
	[108] = "100 High 12 - 10.104.3.108",
	[109] = "100 High 13 - 10.104.3.109",
	[110] = "100 High 14 - 10.104.3.110",
	[111] = "100 High 15 - 10.104.3.111",
	[128] = "Eth Combo 0 - 10.104.3.128",
	[129] = "Eth Combo 1 - 10.104.3.129",
	[130] = "Eth Combo 2 - 10.104.3.130",
	[131] = "Eth Combo 3 - 10.104.3.131",
	[132] = "Eth Combo 4 - 10.104.3.132",
	[133] = "Eth Combo 5 - 10.104.3.133",
	[134] = "Eth Combo 6 - 10.104.3.134",
	[135] = "Eth Combo 7 - 10.104.3.135",
	[136] = "Eth Combo 8 - 10.104.3.136",
	[137] = "Eth Combo 9 - 10.104.3.137",
	[138] = "Eth Combo 10 - 10.104.3.138",
	[139] = "Eth Combo 11 - 10.104.3.139",
	[140] = "Eth Combo 12 - 10.104.3.140",
	[141] = "Eth Combo 13 - 10.104.3.141",
	[142] = "Eth Combo 14 - 10.104.3.142",
	[143] = "Eth Combo 15 - 10.104.3.143",
	[144] = "1000 High 0 - 10.104.3.144",
	[145] = "1000 High 1 - 10.104.3.145",
	[146] = "1000 High 2 - 10.104.3.146",
	[147] = "1000 High 3 - 10.104.3.147",
	[148] = "1000 High 4 - 10.104.3.148",
	[149] = "1000 High 5 - 10.104.3.149",
	[150] = "1000 High 6 - 10.104.3.150",
	[151] = "1000 High 7 - 10.104.3.151",
	[152] = "1000 High 8 - 10.104.3.152",
	[153] = "1000 High 9 - 10.104.3.153",
	[154] = "1000 High 10 - 10.104.3.154",
	[155] = "1000 High 11 - 10.104.3.155",
	[156] = "1000 High 12 - 10.104.3.156",
	[157] = "1000 High 13 - 10.104.3.157",
	[158] = "1000 High 14 - 10.104.3.158",
	[159] = "1000 High 15 - 10.104.3.159",
	
	[192] = "SerDes Adpater (allgemein) - 10.104.3.192",
	[193] = "ADCAM low - 10.104.3.193",
	[194] = "ADCAM mid - 10.104.3.194",
	[195] = "UCAP - 10.104.3.195",
	[196] = "SerDes xPAD - 10.104.3.196",
	[197] = "SerDes xPAD - 10.104.3.197",
	[198] = "SerDes xPAD from UCAP - 10.104.3.198",
	[199] = "SerDes xPAD from ADCAM - 10.104.3.199",
	
	[200] = "SerDes LIDAR vorne - 10.104.3.200",
	[201] = "SerDes LIDAR vorne links - 10.104.3.201",
	[202] = "SerDes LIDAR vorne rechts - 10.104.3.202",
	[203] = "SerDes LIDAR hinten links - 10.104.3.203",
	[204] = "SerDes LIDAR hinten rechts - 10.104.3.204",
	[205] = "SerDes ARCAM - 110.104.3.205",
	
	[177] = "MRR-MTA-B - 10.104.3.177",
	[178] = "FRR-MTA-B - 10.104.3.178",
	
    [179] = "UCAP TIC (TestInterface Card)- V3H - 10.104.3.179",
    [180] = "UCAP TIC (TestInterface Card)- M3N - 10.104.3.179",
	[181] = "USS MTA  - 10.104.3.181",
	[16] = "Logger 1 - 10.104.3.16",
	[17] = "Logger 2 - 10.104.3.17",
	[18] = "Logger 3 - 10.104.3.18"	
		
}

local PLP_CONFIG_PROBE_TYPE = {
	[0x02] = "CM LIN Combo",
	[0x04] = "CM CAN Combo",
	[0x06] = "CM 100 High",
	[0x08] = "CM Eth Combo",
	[0x0A] = "CM 1000 High",
	[0x10] = "SensorSpezifisch",
	[0x20] = "Logger",
	[0x40] = "CM Serdes GMSL2/3"
}
	
---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
    
local table_plp_vendor_specific_status = DissectorTable.new("plp.vendorspecificprobe", "plp.config.vendorspecificprobe")

--------------------------------
-- Table with fields alignment
local al_f = {
  ["st_probe"] = 42
}

do
	-- Create a new dissector
	STATUS_PROBE_PROTO = Proto("PLP_STATUS_PROBE", "PLP STATUS PROBE")
	const_status_probe_PLP_Type = 0x01
	
	-- Create the protocol fields
	local f = STATUS_PROBE_PROTO.fields
	
	f.vendor_id = ProtoField.uint8("plp_status_probe.vendor_id", 
									_ljust("VendorID", al_f["st_probe"]), 
									base.HEX, 
									ENUM_VENDOR_ID_TYPE)
	f.probe_version = ProtoField.uint8("plp_status_probe.probe_version", 
										_ljust("ProbeVersion", al_f["st_probe"]), 
										base.HEX)
	f.probe_type = ProtoField.uint8("plp_status_probe.probe_type", 
									_ljust("ProbeType", al_f["st_probe"]), 
									base.HEX,
									PLP_CONFIG_PROBE_TYPE) 
	f.length_vendor_specific = ProtoField.uint8("plp_status_probe.length_vendor_specific", 
								_ljust('Length of "Vendor specific" field in bytes',
								al_f["st_probe"]), 
								base.DEC)
	f.probe_id = ProtoField.uint16("plp_status_probe.probe_id", 
									_ljust("ProbeID", al_f["st_probe"]),
									base.dec)
	f.probe_serial_number = ProtoField.uint32("plp_status_probe.probe_serial_number", 
											   _ljust("ProbeSerialNumber", al_f["st_probe"]), 
											   base.dec)
	f.vendor_specific_probe = ProtoField.bytes("plp_status_probe.vendor_specific_probe", 
												_ljust("VendorSpecificProbe", 
												al_f["st_probe"]), 
												base.NONE)
	
	local plp_status_probe_table = DissectorTable.new("plp_status_probe", "plp_status_probe")


	-- The dissector function
	function STATUS_PROBE_PROTO.dissector (buffer, pinfo, tree)
		-- Adding fields to the tree
		local status_tree = tree:add (STATUS_PROBE_PROTO, buffer())
	
		-- some offsets	
		O_VENDOR_ID = 0
		O_PROBE_VERSION = 1
		O_PROBE_TYPE = 2
		O_RESERVED = 3
		O_LENGTH = 4
		O_PROBE_ID = 6
		O_PROBE_SERIAL_NUMBER = 8
		O_VENDOR_SPECIFIC_PROBE = 12

		-- Field VendorID
        local vendor_specific_val = buffer:range(O_VENDOR_ID,1):uint()
		status_tree:add(f.vendor_id, buffer:range(O_VENDOR_ID,1))
		
		-- Field ProbeVersion
		status_tree:add(f.probe_version, buffer:range(O_PROBE_VERSION,1))

		-- Field ProbeType
		probe_type_val = buffer:range(O_PROBE_TYPE,1):uint()
		status_tree:add(f.probe_type, buffer:range(O_PROBE_TYPE,1))
		
		-- Field Length
		-- dissect the length
		local vendor_length = buffer:range(O_LENGTH,2):uint()
		status_tree:add(f.length_vendor_specific, buffer:range(O_LENGTH,2))
		
		-- Field ProbeID
		local probe_id_val = buffer:range(O_PROBE_ID,2):uint()
		local probe_id_node = status_tree:add(f.probe_id, buffer:range(O_PROBE_ID,2))
		
		enum_plp_probe_id = PLP_PROBE_ID[probe_id_val]
		if enum_plp_probe_id ~= nil then
			probe_id_node:append_text(" ("..enum_plp_probe_id..")")
		end
		
		-- Field ProbeSerialNumber
		probe_serial_number_val = buffer:range(O_PROBE_SERIAL_NUMBER,4):uint()
		serial_number_node = status_tree:add(f.probe_serial_number, probe_serial_number_val)
		-- In case the serial number is composed by the 4 last bytes of the MAC address, show SN also with "MAC format"
        local serial_number_str = get_serial_number_from_bytes(probe_serial_number_val)
		if serial_number_str == src_mac_address then
        	serial_number_node:append_text(" ("..serial_number_str..") ")
        end

		-- Field VendorSpecificProbe
		-- dissect vendor specific probe info
		if vendor_length > 0 then
			local newtvb = buffer(O_VENDOR_SPECIFIC_PROBE,vendor_length):tvb()
			table_plp_vendor_specific_status:try(vendor_specific_val, newtvb, pinfo, status_tree)
		end

	end
	
	plp_table = DissectorTable.get("plp.type")
	plp_table:add(const_status_probe_PLP_Type, STATUS_PROBE_PROTO)
end

get_serial_number_from_bytes = function (bytes)
	-- format of the serial number: mac[2].mac[3].mac[4].mac[5]
	a = bit32.band(bit32.rshift(bytes, 24), 0xff)
	b = bit32.band(bit32.rshift(bytes, 16), 0xff)
	c = bit32.band(bit32.rshift(bytes, 8), 0xff)
	d = bit32.band(bytes, 0xff)
	
	return (string.format("%02x",a)..":"..string.format("%02x",b)..":"..string.format("%02x",c)..":"..string.format("%02x",d))
	
end