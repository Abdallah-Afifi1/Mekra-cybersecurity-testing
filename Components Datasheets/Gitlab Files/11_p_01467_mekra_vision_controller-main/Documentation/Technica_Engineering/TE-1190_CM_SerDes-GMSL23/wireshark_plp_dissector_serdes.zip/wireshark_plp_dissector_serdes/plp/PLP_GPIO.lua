-------------------------------------------------------------------
-- PLP Lua dissector
--
-- PLP GPIO protocol dissector
--
-- @author: Guillem Prats
-------------------------------------------------------------------

do
	-- Create a new dissector
	GPIO_PROTO = Proto("PLP_GPIO", "PLP GPIO")
	const_gpio_MsgType = 0x000A

	-- Maximum number of GPIOs supported
	const_gpio_MAX_GPIOs = 96
	const_gpio_MAX_BYTES = const_gpio_MAX_GPIOs/8

	-- Table for all gpio fields
	local plp_gpio_fields = {}

	-- Create dynamically fields for each byte. This allows to filter by byte.
	for i = 0,const_gpio_MAX_BYTES,1 do
		local key_name = "gpio_group_" .. i*8 .. "_" .. (i*8+7)
		local str_name = "GPIOs " .. i*8 .. "-" .. i*8+7
		plp_gpio_fields[key_name] = ProtoField.uint8 ("plp." .. key_name, _ljust(str_name, 13), base.HEX)
	end

	-- Create dynamically fields for each gpio. This allows to filter by GPIO.
	for i = 0,const_gpio_MAX_GPIOs,1 do
		local key_name = "gpio." .. i
		local group = i%8
		local group_name = "gpio_group_" .. group*8 .. "_" .. (group*8+7)
		local str_name = "GPIO " .. i
		local exp = 7-(i%8)
		plp_gpio_fields[key_name] = ProtoField.bool("plp." .. group_name .. "." .. key_name, _ljust(str_name, 8), 8, {"[1]", "[0]"}, 2^exp, str_name)
	end

	-- Register the ProtoFields
	GPIO_PROTO.fields = plp_gpio_fields

	-- The dissector function
	function GPIO_PROTO.dissector (buffer, pinfo, tree)
		length = buffer:len()
		if length == 0 then return end

		-- Number of GPIOs to extract (protect maximum defined)
		local number_gpios = buffer:len()*8
		local number_bytes = buffer:len()
		if number_gpios > const_gpio_MAX_GPIOs then
			number_gpios = const_gpio_MAX_GPIOs
			number_bytes = const_gpio_MAX_BYTES
		end

		-- Adding fields to the tree
		local plp_gpio_tree = tree:add(GPIO_PROTO, buffer())
		
		for i = 0,number_bytes-1, 1 do
			local group_name = "gpio_group_" .. i*8 .. "_" .. (i*8+7)
			local gpios_tree = plp_gpio_tree:add(plp_gpio_fields[group_name], buffer:range(i, 1))

			for z = 0,7,1 do
				local key_name = "gpio." .. (i*8 + z)
				gpios_tree:add(plp_gpio_fields[key_name], buffer:range(i, 1))
			end	
		end
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_gpio_MsgType, GPIO_PROTO)
end