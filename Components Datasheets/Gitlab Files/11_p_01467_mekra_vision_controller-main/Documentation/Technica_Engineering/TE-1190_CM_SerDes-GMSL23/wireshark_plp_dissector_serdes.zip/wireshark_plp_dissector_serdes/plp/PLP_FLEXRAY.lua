-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------

---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["plp_fr"] = 8
}

do
	-- Create a new dissector
	FLEXRAY_PROTO = Proto("PLP_FLEXRAY", "PLP FLEXRAY")
	const_fr_MsgType = 0x8

	
	-- Create the protocol fields
	local f = FLEXRAY_PROTO.fields
	
	f.cycle = ProtoField.uint8 ("plp_flexray.cycle", _ljust("Cycle", al_f["plp_fr"]), base.DEC)
	f.frame_id = ProtoField.uint16 ("plp_flexray.frame_id", _ljust("Frame ID", al_f["plp_fr"]), base.DEC)
	f.length = ProtoField.uint8 ("plp_flexray.length", _ljust("Length", al_f["plp_fr"]), base.DEC)
	f.payload = ProtoField.bytes ("plp_flexray.payload", _ljust("Payload", al_f["plp_fr"]))
	
	local plp_flexray_table = DissectorTable.new("plp_flexray", "plp_flexray")

	-- The dissector function
	function FLEXRAY_PROTO.dissector (buffer, pinfo, tree)
	
		local O_CYCLE = 0
		local O_FRAME_ID = 1
		local O_LENGTH = 3
		local O_PAYLOAD = 4
		
		
		-- Adding fields to the tree
		local flexray_tree = tree:add (FLEXRAY_PROTO, buffer())
	
		-- dissect the cylce
		flexray_tree:add(f.cycle, buffer:range(O_CYCLE,1))
		
		--dissect the frame_id
		flexray_tree:add(f.frame_id, buffer:range(O_FRAME_ID, 2))
		
		-- dissect the length
		length = buffer(O_LENGTH, 1)
		length_val = buffer(O_LENGTH, 1):uint()
		flexray_tree:add(f.length, buffer:range(O_LENGTH,1))
		
		-- dissect the payload
		flexray_tree:add(f.payload, buffer:range(O_PAYLOAD,length_val))
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_fr_MsgType, FLEXRAY_PROTO)
end