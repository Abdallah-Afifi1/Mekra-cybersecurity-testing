--------------------------------------------------------------------------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Guillem Prats
--
-------------------------------------------------------------------

-- Table with fields alignment
local al_f = {
	["vendor"] = 20
}

do
	-- Create a new dissector
	VENDOR_STATUS_PROBE_PROTO_CM_SERDES_GMSL2_3 = Proto("PLP_STATUS_PROBE_VENDOR_TECHNICA_CM_SERDES_GMSL_2_3", "PLP Vendor Specific Probe Technica Engineering - CM Serdes GMSL 2/3")
	c_PROBE_TYPE_CM_SERDES_GMSL2_3 = 0x40

  -- Table for the protocol fields
	local plp_status_probe_fields = {
		silicon_temperature = ProtoField.int8 ("plp.status_probe.vendor.te.serdes.silicon_temperature", _ljust("Silicon Temperature", al_f["vendor"]), base.DEC),
		lifetime_counter = ProtoField.uint16("plp.status_probe.vendor.te.serdes.lifetime_counter", _ljust("Lifetime counter", al_f["vendor"]), base.DEC),
		error_flags = ProtoField.uint16("plp.status_probe.vendor.te.serdes.error_flags", _ljust("Error Flags", al_f["vendor"]), base.HEX),
		i2c_0_error_init = ProtoField.bool ("plp.status_probe.vendor.te.serdes.i2c_0_error_init", _ljust("I2C 0 Error Init. Seq.", 20), 16, {"Yes", "No"}, 0x01),
        i2c_1_error_init = ProtoField.bool ("plp.status_probe.vendor.te.serdes.i2c_1_error_init", _ljust("I2C 1 Error Init. Seq.", 20), 16, {"Yes", "No"}, 0x02),
		i2c_2_error_init = ProtoField.bool ("plp.status_probe.vendor.te.serdes.i2c_2_error_init", _ljust("I2C 2 Error Init. Seq.", 20), 16, {"Yes", "No"}, 0x04),
        i2c_3_error_init = ProtoField.bool ("plp.status_probe.vendor.te.serdes.i2c_3_error_init", _ljust("I2C 3 Error Init. Seq.", 20), 16, {"Yes", "No"}, 0x08),
		sfp_a_10g_tx_packets = ProtoField.uint16("plp.status_probe.vendor.te.serdes.sfp_a_tx_cnt", _ljust("SFP-A 10G Tx Packets", al_f["vendor"]), base.DEC),
		sfp_b_10g_tx_packets = ProtoField.uint16("plp.status_probe.vendor.te.serdes.sfp_b_tx_cnt", _ljust("SFP-B 10G Tx Packets", al_f["vendor"]), base.DEC),
		sfp_c_10g_tx_packets = ProtoField.uint16("plp.status_probe.vendor.te.serdes.sfp_c_tx_cnt", _ljust("SFP-C 10G Tx Packets", al_f["vendor"]), base.DEC),
		sfp_d_10g_tx_packets = ProtoField.uint16("plp.status_probe.vendor.te.serdes.sfp_d_tx_cnt", _ljust("SFP-D 10G Tx Packets", al_f["vendor"]), base.DEC),
	}

	-- Register the ProtoFields
	VENDOR_STATUS_PROBE_PROTO_CM_SERDES_GMSL2_3.fields = plp_status_probe_fields

	-- Create the protocol fields
	local plp_TE_table = DissectorTable.new("plp_vendor_technica_probe_cm_serdes", "plp_vendor_technica_probe")

	-- The dissector function
	function VENDOR_STATUS_PROBE_PROTO_CM_SERDES_GMSL2_3.dissector (buffer, pinfo, tree)    
		-- offsets	
		O_SILICON_TEMPERATURE = 0
		O_LIFETIME_COUNTER = 1
		O_ERROR_FLAGS = 3
		O_SFP_A_10G_TX_CNT = 5
		O_SFP_B_10G_TX_CNT = 9
		O_SFP_C_10G_TX_CNT = 13
		O_SFP_D_10G_TX_CNT = 17

		local remaining_bytes = buffer:len()
		
		-- Adding fields to the tree
		local technica_tree = tree:add (VENDOR_STATUS_PROBE_PROTO_CM_SERDES_GMSL2_3, buffer())

		-- Silicon temperature
		if remaining_bytes >= 1 then
			technica_tree:add(plp_status_probe_fields.silicon_temperature, buffer:range(O_SILICON_TEMPERATURE, 1)):append_text(" ºC")
			remaining_bytes = remaining_bytes - 1
		end
		
		-- Lifetime counter
		if remaining_bytes >= 2 then
			technica_tree:add(plp_status_probe_fields.lifetime_counter, buffer:range(O_LIFETIME_COUNTER, 2)):append_text("h")	
			remaining_bytes = remaining_bytes - 2
		end	 

		-- Error flags
		if remaining_bytes >= 2 then
			local error_flags = technica_tree:add(plp_status_probe_fields.error_flags, buffer:range(O_ERROR_FLAGS, 2))	
			error_flags:add(plp_status_probe_fields.i2c_0_error_init, buffer:range(O_ERROR_FLAGS, 2))
			error_flags:add(plp_status_probe_fields.i2c_1_error_init, buffer:range(O_ERROR_FLAGS, 2))
			error_flags:add(plp_status_probe_fields.i2c_2_error_init, buffer:range(O_ERROR_FLAGS, 2))
			error_flags:add(plp_status_probe_fields.i2c_3_error_init, buffer:range(O_ERROR_FLAGS, 2))
			remaining_bytes = remaining_bytes - 2
		end	 

		-- SFP+ A 10G Tx packets
		if remaining_bytes >= 4 then
			technica_tree:add(plp_status_probe_fields.sfp_a_10g_tx_packets, buffer:range(O_SFP_A_10G_TX_CNT, 4)):append_text(" pkts")	
			remaining_bytes = remaining_bytes - 4
		end	 

		-- SFP+ B 10G Tx packets
		if remaining_bytes >= 4 then
			technica_tree:add(plp_status_probe_fields.sfp_b_10g_tx_packets, buffer:range(O_SFP_B_10G_TX_CNT, 4)):append_text(" pkts")		
			remaining_bytes = remaining_bytes - 4
		end	 

		-- SFP+ C 10G Tx packets
		if remaining_bytes >= 4 then
			technica_tree:add(plp_status_probe_fields.sfp_c_10g_tx_packets, buffer:range(O_SFP_C_10G_TX_CNT, 4)):append_text(" pkts")		
			remaining_bytes = remaining_bytes - 4
		end	 

		-- SFP+ D 10G Tx packets
		if remaining_bytes >= 4 then
			technica_tree:add(plp_status_probe_fields.sfp_d_10g_tx_packets, buffer:range(O_SFP_D_10G_TX_CNT, 4)):append_text(" pkts")		
			remaining_bytes = remaining_bytes - 4
		end	 
	end
	
	local plp_table_serdes = DissectorTable.get("plp.vendorspecificprobe_serdes")
	plp_table_serdes:add(c_PROBE_TYPE_CM_SERDES_GMSL2_3, VENDOR_STATUS_PROBE_PROTO_CM_SERDES_GMSL2_3)
end