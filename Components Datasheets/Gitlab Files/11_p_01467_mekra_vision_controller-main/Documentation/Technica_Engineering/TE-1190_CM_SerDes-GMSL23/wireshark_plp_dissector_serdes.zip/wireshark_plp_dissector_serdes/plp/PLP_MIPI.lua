-------------------------------------------------------------------
-- PLP Lua dissector
--
-- PLP MIPI protocol dissector. 
-- Currently we just dissect first (FS) and last packets (Metadata, and FE if completed)
--
-- @author: Guillem Prats
-------------------------------------------------------------------

-- enums
local ENUM_TYPE_DATA ={
    [0x00] = "Uncompressed RAW data, densely packet",
    [0x01] = "Uncompressed RAW data, 0-padding, unaligned",
    [0x02] = "Uncompressed RAW data, 0-padding, aligned",
    [0x20] = "Lossless JPEG compressed RAW",
    [0x30] = "Lossless JPEG compressed YUV",
    [0x80] = "Meta Data",
    [0x40] = "LZRW1A"
}

local ENUM_MIPI_DATATYPE ={
    [0x00] = "Frame Start",
    [0x01] = "Frame End",
    [0x12] = "Embedded Data",
    [0x1E] = "YUV 4:2:2 8-bit",
    [0x2A] = "RAW8",
    [0x2B] = "RAW10",
    [0x2C] = "RAW12",
    [0x2D] = "RAW14",
    [0x2E] = "RAW16",
    [0x2F] = "RAW20",
    [0x30] = "User Defined 8-bit Data",
    [0x31] = "User Defined 8-bit Data",
    [0x32] = "User Defined 8-bit Data",
    [0x33] = "User Defined 8-bit Data",
    [0x34] = "User Defined 8-bit Data",
    [0x35] = "User Defined 8-bit Data",
    [0x36] = "User Defined 8-bit Data",
    [0x37] = "User Defined 8-bit Data"
}

local ENUM_RAW_SCHEME ={
    [0x00] = "Undefined",
    [0x01] = "RCCC",
    [0x02] = "CRCC",
    [0x03] = "CCRC",
    [0x04] = "CCCR",
    [0x06] = "CRGC",
    [0x11] = "GRBG",
    [0x12] = "GBRG",
    [0x13] = "RGGB",
    [0x14] = "BGGR",
    [0x20] = "RYYCy"
}

local ENUM_METADATA_COMPRESSION ={
    [0x00] = "Uncompressed",
    [0x01] = "Lossless JPEG, RAW (Frame-based)",
    [0x02] = "Lossless JPEG, YUV (Frame-based)",
    [0x81] = "Lossless JPEG, RAW (Line-based)",
    [0x82] = "Lossless JPEG, YUV (Line-based)",
    [0x10] = "LZRW1A (LIDAR)"
}

-- offsets
local c_PROBE_FLAGS_OFFSET = 10
local c_SOURCE_DATA_OFFSET = 28

local c_DISSECT_IMAGE_LINE = false

do
	-- Create a new dissector
	MIPI_PROTO = Proto("PLP_MIPI", "PLP MIPI")
	const_mipi_MsgType = 0x0101

	-- Table for all mipi fields
	local plp_mipi_fields = {
        chunk_length = ProtoField.uint16("plp_mipi.chunk_length", "Length", base.DEC),
        chunk_type = ProtoField.uint8("plp_mipi.type", "Type", base.HEX, ENUM_TYPE_DATA),
        chunk_subtype = ProtoField.uint8("plp_mipi.subtype", "Subtype", base.HEX, ENUM_MIPI_DATATYPE),

        timestamp_field = ProtoField.uint64("plp_mipi.timestamp_field", _ljust("Timestamp", 20), base.HEX),
        timestamp_async = ProtoField.bool ("plp_mipi.timestamp_async", _ljust("Sync?", 20), 8, {"Asynchronous", "Synchronous or standalone"}, 0x80, "Asynchronous?"),
        timestamp_reserved = ProtoField.bool ("plp_mipi.timestamp_reserved", _ljust("Reserved", 20), 8, nil, 0x40, "Reserved"),
        timestamp_val = ProtoField.uint64("plp_mipi.timestamp_val", _ljust("timestamp_val", 20), base.DEC),
        timestamp = ProtoField.absolute_time ("plp_mipi.timestamp", _ljust("Timestamp", 20)),

        chunk_header_error_flags = ProtoField.uint16("plp_mipi.header_errors", "Header Error Flags", base.HEX),
        chunk_header_error_flags_ecc_error_2 = ProtoField.bool ("plp_mipi.header_error_flags_ecc_error_2", _ljust("ECC Error 2-bits", 20), 16, {"Yes", "No"}, 0x01),
        chunk_header_error_flags_ecc_error_1 = ProtoField.bool ("plp_mipi.header_error_flags_ecc_error_1", _ljust("ECC Error 1-bit", 20), 16, {"Yes", "No"}, 0x02),
        chunk_header_error_flags_receiver_fifo_overrun = ProtoField.bool ("plp_mipi.header_error_flags_receiver_fifo_overrun", _ljust("Receiver FIFO Overrun", 20), 16, {"Yes", "No"}, 0x04),
        chunk_header_error_flags_pixel_fifo_overrun = ProtoField.bool ("plp_mipi.header_error_flags_pixel_fifo_overrun", _ljust("Pixel FIFO Overrun", 20), 16, {"Yes", "No"}, 0x08),

        chunk_image_data = ProtoField.bytes("plp_mipi.image_data", "Image Data"),
        chunk_frame_counter = ProtoField.uint16("plp_mipi.frame_counter", "Frame Counter",base.DEC),
        chunk_payload_error_flags = ProtoField.uint16("plp_mipi.payload_errors", "Payload Error Flags", base.HEX),
        chunk_payload_error_flags_crc_error = ProtoField.bool ("plp_mipi.payload_error_flags_crc_error", _ljust("CRC Error", 20), 16, {"Yes", "No"}, 0x01),
        chunk_payload_error_flags_packet_too_short = ProtoField.bool ("plp_mipi.payload_error_flags_packet_too_short", _ljust("Packet too short", 20), 16, {"Yes", "No"}, 0x02),
        chunk_payload_error_flags_receiver_fifo_overrun = ProtoField.bool ("plp_mipi.payload_error_flags_receiver_fifo_overrun", _ljust("Receiver FIFO Overrun", 20), 16, {"Yes", "No"}, 0x04),
        chunk_payload_error_flags_pixel_fifo_overrun = ProtoField.bool ("plp_mipi.payload_error_flags_pixel_fifo_overrun", _ljust("Pixel FIFO Overrun", 20), 16, {"Yes", "No"}, 0x08),
        
        chunk_pixel_format = ProtoField.uint8("plp_mipi.pixel_format", "Pixel Format", base.HEX, ENUM_MIPI_DATATYPE),
        chunk_raw_scheme = ProtoField.uint8("plp_mipi.raw_scheme", "RAW Color Scheme", base.HEX, ENUM_RAW_SCHEME),
        chunk_imager_type = ProtoField.bytes("plp_mipi.imager_type", "Imager Type"),
        chunk_compression = ProtoField.uint8("plp_mipi.compression", "Compression", base.HEX, ENUM_METADATA_COMPRESSION),
        chunk_width = ProtoField.uint16("plp_mipi.width", "Width", base.DEC),
        chunk_height = ProtoField.uint16("plp_mipi.height", "Height", base.DEC),
        chunk_frame_counter_32 = ProtoField.uint32("plp_mipi.frame_counter_32", "Frame Counter", base.DEC),

        chunk_error_flags = ProtoField.uint16("plp_mipi.error_flags", "Error Flags", base.HEX),
        chunk_metadata_header_rx_fifo_overflow = ProtoField.bool ("plp_mipi.chunk_metadata_header_rx_fifo_overflow", _ljust("Header RX FIFO Overflow", 20), 16, {"Yes", "No"}, 0x01),
        chunk_metadata_header_ecc_2_error = ProtoField.bool ("plp_mipi.chunk_metadata_header_ecc_2_error", _ljust("Header ECC 2-bit errors", 20), 16, {"Yes", "No"}, 0x02),
        chunk_metadata_header_ecc_1_error = ProtoField.bool ("plp_mipi.chunk_metadata_header_ecc_1_error", _ljust("Header ECC 1-bit error", 20), 16, {"Yes", "No"}, 0x04),
        chunk_metadata_packet_too_short = ProtoField.bool ("plp_mipi.chunk_metadata_packet_too_short", _ljust("Packet too short", 20), 16, {"Yes", "No"}, 0x08),
        chunk_metadata_packet_crc_error = ProtoField.bool ("plp_mipi.chunk_metadata_packet_crc_error", _ljust("Packet CRC error", 20), 16, {"Yes", "No"}, 0x10),
        chunk_metadata_packet_rx_fifo_overflow = ProtoField.bool ("plp_mipi.chunk_metadata_packet_rx_fifo_overflow", _ljust("Packet RX FIFO Overflow", 20), 16, {"Yes", "No"}, 0x20),

        payload = ProtoField.bytes("plp_mipi.payload", "Payload")
	}

	-- Register the ProtoFields
	MIPI_PROTO.fields = plp_mipi_fields

	-- The dissector function
	function MIPI_PROTO.dissector (buffer, pinfo, tree)
        length = buffer:len()
		if length == 0 then return end

        -- Get probe flags value
        local probe_flags_num = buffer(c_PROBE_FLAGS_OFFSET,2):uint()
        local offset_data = c_SOURCE_DATA_OFFSET 

        -- Detect if packet is the first or the last, otherwise we do nothing (as data chunks are packetized)
        if(probe_flags_num & 2 == 2) then -- SoF
            ------------------ START OF FRAME CHUNK --------------
            local subtree_sof = tree:add(MIPI_PROTO, buffer(), "MIPI CSI-2 Start of Frame Chunk")
            subtree_sof:add(plp_mipi_fields.chunk_length, buffer(offset_data,2))
            subtree_sof:add(plp_mipi_fields.chunk_type, buffer(offset_data+2,1))
            subtree_sof:add(plp_mipi_fields.chunk_subtype, buffer(offset_data+3,1))

            -- create timestamp tree
            local timestamp_field = subtree_sof:add(plp_mipi_fields.timestamp_field, buffer:range(offset_data + 4, 8))
            
            -- dissect the Time is Asynchronous bit.
            timestamp_field:add(plp_mipi_fields.timestamp_async, buffer:range(offset_data + 4, 1))	
            timestamp_field:add(plp_mipi_fields.timestamp_reserved, buffer:range(offset_data + 4, 1))	
            
            nsecs_raw_h = buffer:range(offset_data + 4, 4):uint()
            nsecs_raw_l = buffer:range(offset_data + 4, 4):uint()
            nstime, timestamp_val = get_nstime(nsecs_raw_h, nsecs_raw_l)
            timestamp_field:add(plp_mipi_fields.timestamp_val, buffer:range(offset_data + 4, 8), timestamp_val)
            timestamp_field:add(plp_mipi_fields.timestamp, buffer:range(offset_data + 4, 8),nstime)

			local chunk_header_error_flags_field = subtree_sof:add(plp_mipi_fields.chunk_header_error_flags, buffer(offset_data+12,2))
            chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_2, buffer:range(offset_data+12, 2))
            chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_1, buffer:range(offset_data+12, 2))
            chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_receiver_fifo_overrun, buffer:range(offset_data+12, 2))
            chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_pixel_fifo_overrun, buffer:range(offset_data+12, 2))

			subtree_sof:add(plp_mipi_fields.chunk_frame_counter, buffer(offset_data+14,2))

			local chunk_payload_error_flags = subtree_sof:add(plp_mipi_fields.chunk_payload_error_flags, buffer(offset_data+16,2))
            chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_crc_error, buffer:range(offset_data+16, 2))
            chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_packet_too_short, buffer:range(offset_data+16, 2))
            chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_receiver_fifo_overrun, buffer:range(offset_data+16, 2))
            chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_pixel_fifo_overrun, buffer:range(offset_data+16, 2))

            ----------------- IMAGE CHUNK ---------------
            if c_DISSECT_IMAGE_LINE then
                offset_data = offset_data + 18

                local length_chunk = buffer(offset_data,2):uint()
    
                local subtree_image = tree:add(MIPI_PROTO, buffer(), "MIPI CSI-2 Video Line")
                subtree_image:add(plp_mipi_fields.chunk_length, buffer(offset_data,2))
                subtree_image:add(plp_mipi_fields.chunk_type, buffer(offset_data+2,1))
                subtree_image:add(plp_mipi_fields.chunk_subtype, buffer(offset_data+3,1))
    
                -- create timestamp tree
                local timestamp_field = subtree_image:add(plp_mipi_fields.timestamp_field, buffer:range(offset_data + 4, 8))
                
                -- dissect the Time is Asynchronous bit.
                timestamp_field:add(plp_mipi_fields.timestamp_async, buffer:range(offset_data + 4, 1))	
                timestamp_field:add(plp_mipi_fields.timestamp_reserved, buffer:range(offset_data + 4, 1))	
                
                nsecs_raw_h = buffer:range(offset_data + 4, 4):uint()
                nsecs_raw_l = buffer:range(offset_data + 4, 4):uint()
                nstime, timestamp_val = get_nstime(nsecs_raw_h, nsecs_raw_l)
                timestamp_field:add(plp_mipi_fields.timestamp_val, buffer:range(offset_data + 4, 8), timestamp_val)
                timestamp_field:add(plp_mipi_fields.timestamp, buffer:range(offset_data + 4, 8),nstime)
    
                local chunk_header_error_flags_field = subtree_image:add(plp_mipi_fields.chunk_header_error_flags, buffer(offset_data+12,2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_2, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_1, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_receiver_fifo_overrun, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_pixel_fifo_overrun, buffer:range(offset_data+12, 2))
    
                if length < offset_data+length_chunk-2 then
                    length_chunk = length + 2 - offset_data
                end
    
                subtree_image:add(plp_mipi_fields.chunk_image_data, buffer(offset_data+14,length_chunk-2-14))
    
                offset_data = offset_data + length_chunk - 2
    
                if length >= offset_data + 2 then
                    local chunk_payload_error_flags = subtree_image:add(plp_mipi_fields.chunk_payload_error_flags, buffer(offset_data,2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_crc_error, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_packet_too_short, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_receiver_fifo_overrun, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_pixel_fifo_overrun, buffer:range(offset_data, 2))
                end   
            else
                offset_data = offset_data + 18
                local payload = tree:add(MIPI_PROTO, buffer(), "Data" .. " (" .. (buffer:len() - offset_data)  .. " bytes)")
                payload:add(plp_mipi_fields.payload, buffer(offset_data,-1))  
            end
        elseif (probe_flags_num & 1 == 1) then  -- EoF
            local length_metadata = 25
            local length_eof = 18
            local source_data_length = buffer:len()
            local offset_metadata = buffer:len() - length_metadata
            local offset_eof = offset_metadata - length_eof

            -- add payload data
            if offset_eof - c_SOURCE_DATA_OFFSET > 0 then
                offset_data = c_SOURCE_DATA_OFFSET
                local payload = tree:add(MIPI_PROTO, buffer(), "Data" .. " (" .. (buffer:len() - offset_data)  .. " bytes)")
                payload:add(plp_mipi_fields.payload, buffer(offset_data, offset_eof - c_SOURCE_DATA_OFFSET))
            end

            -- check if we have the end of frame chunk completed
            if offset_eof >= c_SOURCE_DATA_OFFSET then
                offset_data = offset_eof
                ------------------ END OF FRAME CHUNK --------------
                local subtree_sof = tree:add(MIPI_PROTO, buffer(), "MIPI CSI-2 End of Frame Chunk")
                subtree_sof:add(plp_mipi_fields.chunk_length, buffer(offset_data,2))
                subtree_sof:add(plp_mipi_fields.chunk_type, buffer(offset_data+2,1))
                subtree_sof:add(plp_mipi_fields.chunk_subtype, buffer(offset_data+3,1))

                -- create timestamp tree
                local timestamp_field = subtree_sof:add(plp_mipi_fields.timestamp_field, buffer:range(offset_data + 4, 8))
                
                -- dissect the Time is Asynchronous bit.
                timestamp_field:add(plp_mipi_fields.timestamp_async, buffer:range(offset_data + 4, 1))	
                timestamp_field:add(plp_mipi_fields.timestamp_reserved, buffer:range(offset_data + 4, 1))	
                
                nsecs_raw_h = buffer:range(offset_data + 4, 4):uint()
                nsecs_raw_l = buffer:range(offset_data + 4, 4):uint()
                nstime, timestamp_val = get_nstime(nsecs_raw_h, nsecs_raw_l)
                timestamp_field:add(plp_mipi_fields.timestamp_val, buffer:range(offset_data + 4, 8), timestamp_val)
                timestamp_field:add(plp_mipi_fields.timestamp, buffer:range(offset_data + 4, 8),nstime)

                local chunk_header_error_flags_field = subtree_sof:add(plp_mipi_fields.chunk_header_error_flags, buffer(offset_data+12,2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_2, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_1, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_receiver_fifo_overrun, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_pixel_fifo_overrun, buffer:range(offset_data+12, 2))

                subtree_sof:add(plp_mipi_fields.chunk_frame_counter, buffer(offset_data+14,2))

                local chunk_payload_error_flags = subtree_sof:add(plp_mipi_fields.chunk_payload_error_flags, buffer(offset_data+16,2))
                chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_crc_error, buffer:range(offset_data+16, 2))
                chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_packet_too_short, buffer:range(offset_data+16, 2))
                chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_receiver_fifo_overrun, buffer:range(offset_data+16, 2))
                chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_pixel_fifo_overrun, buffer:range(offset_data+16, 2)) 
            end
            
            -- check if we have the metadata chunk
            if offset_metadata >= c_SOURCE_DATA_OFFSET then
                offset_data = offset_metadata
                ----------------- METADATA CHUNK ---------------
                local subtree_metadata = tree:add(MIPI_PROTO, buffer(), "MIPI CSI-2 Metadata Chunk")
                
                --Length
                local length_chunk = buffer(offset_metadata,2):uint()
                subtree_metadata:add(plp_mipi_fields.chunk_length, buffer(offset_metadata,2))

                --Type
                local type_data = buffer(offset_metadata + 2,1):uint()
                subtree_metadata:add(plp_mipi_fields.chunk_type, buffer(offset_metadata+2,1))
                
                --MIPI CSI-2 Data Type
                local mipi_data_type = buffer(offset_metadata + 3,1):uint()
                subtree_metadata:add(plp_mipi_fields.chunk_subtype, buffer(offset_data+3,1))
                
                offset_metadata = offset_metadata + 4
                
                --Pixel Format
                local mipi_pix_format = buffer(offset_metadata,1):uint()
                subtree_metadata:add(plp_mipi_fields.chunk_pixel_format, buffer(offset_metadata,1)):append_text(" (" .. ENUM_MIPI_DATATYPE[mipi_pix_format] .. ")")
                
                --RAW Color Scheme
                subtree_metadata:add(plp_mipi_fields.chunk_raw_scheme, buffer(offset_metadata+1,1))
                subtree_metadata:add(plp_mipi_fields.chunk_imager_type, buffer(offset_metadata+2,8))
                subtree_metadata:add(plp_mipi_fields.chunk_compression, buffer(offset_metadata+10,1))
                subtree_metadata:add(plp_mipi_fields.chunk_width, buffer(offset_metadata+11,2))
                subtree_metadata:add(plp_mipi_fields.chunk_height, buffer(offset_metadata+13,2))

                --Frame Counter
                subtree_metadata:add(plp_mipi_fields.chunk_frame_counter_32, buffer(offset_metadata+15,4))

                --Error Flags
                local metadata_error_flags = subtree_metadata:add(plp_mipi_fields.chunk_error_flags, buffer(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_header_rx_fifo_overflow, buffer:range(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_header_ecc_2_error, buffer:range(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_header_ecc_1_error, buffer:range(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_packet_too_short, buffer:range(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_packet_crc_error, buffer:range(offset_metadata+19,2))
                metadata_error_flags:add(plp_mipi_fields.chunk_metadata_packet_rx_fifo_overflow, buffer:range(offset_metadata+19,2))   
            end        
        else -- Video lines
            ----------------- IMAGE CHUNK ---------------
            if c_DISSECT_IMAGE_LINE then
                local length_chunk = buffer(offset_data,2):uint()
    
                local subtree_image = tree:add(MIPI_PROTO, buffer(), "MIPI CSI-2 Video Line Chunk")
                subtree_image:add(plp_mipi_fields.chunk_length, buffer(offset_data,2))
                subtree_image:add(plp_mipi_fields.chunk_type, buffer(offset_data+2,1))
                subtree_image:add(plp_mipi_fields.chunk_subtype, buffer(offset_data+3,1))
    
                -- create timestamp tree
                local timestamp_field = subtree_image:add(plp_mipi_fields.timestamp_field, buffer:range(offset_data + 4, 8))
                
                -- dissect the Time is Asynchronous bit.
                timestamp_field:add(plp_mipi_fields.timestamp_async, buffer:range(offset_data + 4, 1))	
                timestamp_field:add(plp_mipi_fields.timestamp_reserved, buffer:range(offset_data + 4, 1))	
                
                nsecs_raw_h = buffer:range(offset_data + 4, 4):uint()
                nsecs_raw_l = buffer:range(offset_data + 4, 4):uint()
                nstime, timestamp_val = get_nstime(nsecs_raw_h, nsecs_raw_l)
                timestamp_field:add(plp_mipi_fields.timestamp_val, buffer:range(offset_data + 4, 8), timestamp_val)
                timestamp_field:add(plp_mipi_fields.timestamp, buffer:range(offset_data + 4, 8),nstime)
    
                local chunk_header_error_flags_field = subtree_image:add(plp_mipi_fields.chunk_header_error_flags, buffer(offset_data+12,2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_2, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_ecc_error_1, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_receiver_fifo_overrun, buffer:range(offset_data+12, 2))
                chunk_header_error_flags_field:add(plp_mipi_fields.chunk_header_error_flags_pixel_fifo_overrun, buffer:range(offset_data+12, 2))
    
                if length < offset_data+length_chunk-2 then
                    length_chunk = length + 2 - offset_data
                end
    
                subtree_image:add(plp_mipi_fields.chunk_image_data, buffer(offset_data+14,length_chunk-2-14))
    
                offset_data = offset_data + length_chunk - 2
    
                if length >= offset_data + 2 then
                    local chunk_payload_error_flags = subtree_image:add(plp_mipi_fields.chunk_payload_error_flags, buffer(offset_data,2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_crc_error, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_packet_too_short, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_receiver_fifo_overrun, buffer:range(offset_data, 2))
                    chunk_payload_error_flags:add(plp_mipi_fields.chunk_payload_error_flags_pixel_fifo_overrun, buffer:range(offset_data, 2))
                end   
            else
                offset_data = c_SOURCE_DATA_OFFSET
                local payload = tree:add(MIPI_PROTO, buffer(), "Data" .. " (" .. (buffer:len() - offset_data)  .. " bytes)")
                payload:add(plp_mipi_fields.payload, buffer(offset_data,-1))   
            end    
        end
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_mipi_MsgType, MIPI_PROTO)
end
