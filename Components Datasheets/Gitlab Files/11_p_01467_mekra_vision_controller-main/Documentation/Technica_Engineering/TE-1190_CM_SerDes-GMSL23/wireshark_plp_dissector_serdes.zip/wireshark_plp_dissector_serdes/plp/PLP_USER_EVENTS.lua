-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------

local ENUM_VENDOR_ID_TYPE = {
	[0x04] = "AeD",
	[0x08] = "Conti",
	[0x0C] = "Technica",
	[0x10] = "ViGEM",
	[0x14] = "X2E",
	[0x20] = "Magna",
	[0x22] = "Valeo",
	[0x24] = "Aptiv"
}

local PLP_UE_ID = {
    [0x0002] = "Logger Ready",    
    [0x0004] = "Logger Shut Down",
    [0x0100] = "Range ADCAM Low",
    [0x01FF] = "Range ADCAM Low",
    [0x0101] = "ADCAM Low Bus Data Vali-dation Failed",
    [0x0102] = "ADACM Low Raw Data Vali-dation Failed",
    [0x0103] = "ADCAM Low ECU Error / HW Reset",
    [0x0104] = "ADCAM Low Sensors Blind",
    [0x0200] = "Range ADCAM MID",
    [0x02FF] = "Range ADCAM MID",
    [0x0300] = "Range ADCAM High / hPad",
    [0x03FF] = "Range ADCAM High / hPad",
    [0x0400] = "Range UCAP",
    [0x04FF] = "Range UCAP",
    [0x0500] = "Range USS",
    [0x05FF] = "Range USS",
    [0x0600] = "Range SRR",
    [0x06FF] = "Range SRR",
    [0x0700] = "Range MRR",
    [0x07FF] = "Range MRR",
    [0x0800] = "Range FRR",
    [0x08FF] = "Range FRR",
    [0x0900] = "Range LIDAR",
    [0x09FF] = "Range LIDAR"

}

local PLP_PROBE_ID = {
	[48] = "LIN Combo 0 - 10.104.3.48",
	[49] = "LIN Combo 1 - 10.104.3.49",
	[50] = "LIN Combo 2 - 10.104.3.50",
	[51] = "LIN Combo 3 - 10.104.3.51",
	[52] = "LIN Combo 4 - 10.104.3.52",
	[53] = "LIN Combo 5 - 10.104.3.53",
	[54] = "LIN Combo 6 - 10.104.3.54",
	[55] = "LIN Combo 7 - 10.104.3.55",
	[56] = "LIN Combo 8 - 10.104.3.56",
	[57] = "LIN Combo 9 - 10.104.3.57",
	[58] = "LIN Combo 10 - 10.104.3.58",
	[59] = "LIN Combo 11 - 10.104.3.59",
	[60] = "LIN Combo 12 - 10.104.3.60",
	[61] = "LIN Combo 13 - 10.104.3.61",
	[62] = "LIN Combo 14 - 10.104.3.62",
	[63] = "LIN Combo 15 - 10.104.3.63",
	[64] = "CAN Combo 0 - 10.104.3.64",
	[65] = "CAN Combo 1 - 10.104.3.65",
	[66] = "CAN Combo 2 - 10.104.3.66",
	[67] = "CAN Combo 3 - 10.104.3.67",
	[68] = "CAN Combo 4 - 10.104.3.68",
	[69] = "CAN Combo 5 - 10.104.3.69",
	[70] = "CAN Combo 6 - 10.104.3.70",
	[71] = "CAN Combo 7 - 10.104.3.71",
	[72] = "CAN Combo 8 - 10.104.3.72",
	[73] = "CAN Combo 9 - 10.104.3.73",
	[74] = "CAN Combo 10 - 10.104.3.74",
	[75] = "CAN Combo 11 - 10.104.3.75",
	[76] = "CAN Combo 12 - 10.104.3.76",
	[77] = "CAN Combo 13 - 10.104.3.77",
	[78] = "CAN Combo 14 - 10.104.3.78",
	[79] = "CAN Combo 15 - 10.104.3.79",
	[96] = "100 High 0 - 10.104.3.96",
	[97] = "100 High 1 - 10.104.3.97",
	[98] = "100 High 2 - 10.104.3.98",
	[99] = "100 High 3 - 10.104.3.99",
	[100] = "100 High 4 - 10.104.3.100",
	[101] = "100 High 5 - 10.104.3.101",
	[102] = "100 High 6 - 10.104.3.102",
	[103] = "100 High 7 - 10.104.3.103",
	[104] = "100 High 8 - 10.104.3.104",
	[105] = "100 High 9 - 10.104.3.105",
	[106] = "100 High 10 - 10.104.3.106",
	[107] = "100 High 11 - 10.104.3.107",
	[108] = "100 High 12 - 10.104.3.108",
	[109] = "100 High 13 - 10.104.3.109",
	[110] = "100 High 14 - 10.104.3.110",
	[111] = "100 High 15 - 10.104.3.111",
	[128] = "Eth Combo 0 - 10.104.3.128",
	[129] = "Eth Combo 1 - 10.104.3.129",
	[130] = "Eth Combo 2 - 10.104.3.130",
	[131] = "Eth Combo 3 - 10.104.3.131",
	[132] = "Eth Combo 4 - 10.104.3.132",
	[133] = "Eth Combo 5 - 10.104.3.133",
	[134] = "Eth Combo 6 - 10.104.3.134",
	[135] = "Eth Combo 7 - 10.104.3.135",
	[136] = "Eth Combo 8 - 10.104.3.136",
	[137] = "Eth Combo 9 - 10.104.3.137",
	[138] = "Eth Combo 10 - 10.104.3.138",
	[139] = "Eth Combo 11 - 10.104.3.139",
	[140] = "Eth Combo 12 - 10.104.3.140",
	[141] = "Eth Combo 13 - 10.104.3.141",
	[142] = "Eth Combo 14 - 10.104.3.142",
	[143] = "Eth Combo 15 - 10.104.3.143",
	[144] = "1000 High 0 - 10.104.3.144",
	[145] = "1000 High 1 - 10.104.3.145",
	[146] = "1000 High 2 - 10.104.3.146",
	[147] = "1000 High 3 - 10.104.3.147",
	[148] = "1000 High 4 - 10.104.3.148",
	[149] = "1000 High 5 - 10.104.3.149",
	[150] = "1000 High 6 - 10.104.3.150",
	[151] = "1000 High 7 - 10.104.3.151",
	[152] = "1000 High 8 - 10.104.3.152",
	[153] = "1000 High 9 - 10.104.3.153",
	[154] = "1000 High 10 - 10.104.3.154",
	[155] = "1000 High 11 - 10.104.3.155",
	[156] = "1000 High 12 - 10.104.3.156",
	[157] = "1000 High 13 - 10.104.3.157",
	[158] = "1000 High 14 - 10.104.3.158",
	[159] = "1000 High 15 - 10.104.3.159",
	
	[192] = "SerDes Adpater (allgemein) - 10.104.3.192",
	[193] = "ADCAM low - 10.104.3.193",
	[194] = "ADCAM mid - 10.104.3.194",
	[195] = "UCAP - 10.104.3.195",
	[196] = "SerDes xPAD - 10.104.3.196",
	[197] = "SerDes xPAD - 10.104.3.197",
	[198] = "SerDes xPAD from UCAP - 10.104.3.198",
	[199] = "SerDes xPAD from ADCAM - 10.104.3.199",
	
	[200] = "SerDes LIDAR vorne - 10.104.3.200",
	[201] = "SerDes LIDAR vorne links - 10.104.3.201",
	[202] = "SerDes LIDAR vorne rechts - 10.104.3.202",
	[203] = "SerDes LIDAR hinten links - 10.104.3.203",
	[204] = "SerDes LIDAR hinten rechts - 10.104.3.204",
	[205] = "SerDes ARCAM - 110.104.3.205",
	
	[177] = "MRR-MTA-B - 10.104.3.177",
	[178] = "FRR-MTA-B - 10.104.3.178",
	
    [179] = "UCAP TIC (TestInterface Card)- V3H - 10.104.3.179",
    [180] = "UCAP TIC (TestInterface Card)- M3N - 10.104.3.179",
	[181] = "USS MTA  - 10.104.3.181",
	[16] = "Logger 1 - 10.104.3.16",
	[17] = "Logger 2 - 10.104.3.17",
	[18] = "Logger 3 - 10.104.3.18"	
		
}
	
---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
    
local table_plp_vendor_specific_status = DissectorTable.new("plp.userevents", "plp.config.userevents")

    
--------------------------------
-- Table with fields alignment
local al_f = {
  ["user_events"] = 14
}

do
	-- Create a new dissector
	USER_EVENTS_PROTO = Proto("PLP_UE", "PLP USER EVENTS")
	const_status_probe_PLP_Type = 0x00
	
	-- Create the protocol fields
	local f = USER_EVENTS_PROTO.fields
	f.probe_id = ProtoField.uint16("plp_ue.probe_id", _ljust("ProbeID", al_f["user_events"]), base.dec, PLP_PROBE_ID)
    
    f.usereventid = ProtoField.uint16("plp_ue.ue_id", _ljust("User Event ID", al_f["user_events"]), base.HEX, PLP_UE_ID)
   	
	

	local plp_status_probe_table = DissectorTable.new("plp_ue", "plp_ue")

	-- The dissector function
	function USER_EVENTS_PROTO.dissector (buffer, pinfo, tree)
		-- Adding fields to the tree
		local status_tree = tree:add (USER_EVENTS_PROTO, buffer())
	
	
		-- some offsets	
		O_PROBE_ID = 0
		O_UE_ID = 2

		status_tree:add(f.probe_id, buffer:range(O_PROBE_ID,2))
        status_tree:add(f.usereventid, buffer:range(O_UE_ID,2))

		
	end
	
	plp_table = DissectorTable.get("plp.type")
	plp_table:add(const_status_probe_PLP_Type, USER_EVENTS_PROTO)
end