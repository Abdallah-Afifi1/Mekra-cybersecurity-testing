-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------

-- @change me:
dissector_proto_version = "[Dissector v9.0.0]"


-- a table of our default settings - these can be changed by changing
-- the preferences through the GUI or command-line; the Lua-side of that
-- preference handling is at the end of this script file
local DEFAULT_SETTINGS =
{
    enabled                           = true, 					   -- whether this dissector is enabled or not
	port                              = 8336, 					   -- default ether_type for PLP
	port_alt                          = 39422,
	PLP_HEADER_LENGTH                 = 12,
	VD_HDR_LEN                        = 16,
	show_reserved_bytes_in_plp_header = true,
}


---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------
_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end

-- ENUMS

local analog_unit = {
	[0x00] = "1 V.",
	[0x01] = "1 A."
}

local analog_factor = {
	[0x0] = "0.1",
	[0x1] = "0.01",
	[0x2] = "0.001",
	[0x3] = "0.0001",
}

local analog_sample_time = {
	[0x0] = "Probe configured as comparator",
	[0x1] = "2500ms",
	[0x2] = "1000ms",
	[0x3] = "500ms",
	[0x4] = "250ms",
	[0x5] = "100ms",
	[0x6] = "50ms",
	[0x7] = "25ms",
	[0x8] = "10ms",
	[0x9] = "5ms",
	[0xA] = "2,5ms",
	[0xB] = "1ms",
	[0xC] = "0,5ms",
	[0xD] = "0,25ms",
	[0xE] = "0,1ms",
	[0xF] = "0,05ms"	
}

local RS232_bits = {
	[0x0] = "RS232 with 5 bit",
	[0x1] = "RS232 with 6 bit",
	[0x2] = "RS232 with 7 bit",
	[0x3] = "RS232 with 8 bit",
	[0x4] = "RS232 with 9 bit"
}

local ENUM_PLP_TYPE= {
	[0x0] = "UserEvent",
	[0x1] = "StatusProbe",
	[0x2] = "StatusBus",
	[0x3] = "Logging Stream",
	[0x4] = "StatusConfig",
	[0x5] = "Reserved",
	[0x6] = "Reserved",
	[0x7] = "Reserved",
	[0x8] = "Reserved",
	[0x9] = "Reserved",
	[0xA] = "Replay Data",
	[0xB] = "Reserved",
	[0xC] = "Reserved",
	[0xD] = "Reserved",
	[0xE] = "Reserved",
	[0xF] = "Reserved"		
}

local PLP_PROBE_ID = {
	[48] = "LIN Combo 0 - 10.104.3.48",
	[49] = "LIN Combo 1 - 10.104.3.49",
	[50] = "LIN Combo 2 - 10.104.3.50",
	[51] = "LIN Combo 3 - 10.104.3.51",
	[52] = "LIN Combo 4 - 10.104.3.52",
	[53] = "LIN Combo 5 - 10.104.3.53",
	[54] = "LIN Combo 6 - 10.104.3.54",
	[55] = "LIN Combo 7 - 10.104.3.55",
	[56] = "LIN Combo 8 - 10.104.3.56",
	[57] = "LIN Combo 9 - 10.104.3.57",
	[58] = "LIN Combo 10 - 10.104.3.58",
	[59] = "LIN Combo 11 - 10.104.3.59",
	[60] = "LIN Combo 12 - 10.104.3.60",
	[61] = "LIN Combo 13 - 10.104.3.61",
	[62] = "LIN Combo 14 - 10.104.3.62",
	[63] = "LIN Combo 15 - 10.104.3.63",
	[64] = "CAN Combo 0 - 10.104.3.64",
	[65] = "CAN Combo 1 - 10.104.3.65",
	[66] = "CAN Combo 2 - 10.104.3.66",
	[67] = "CAN Combo 3 - 10.104.3.67",
	[68] = "CAN Combo 4 - 10.104.3.68",
	[69] = "CAN Combo 5 - 10.104.3.69",
	[70] = "CAN Combo 6 - 10.104.3.70",
	[71] = "CAN Combo 7 - 10.104.3.71",
	[72] = "CAN Combo 8 - 10.104.3.72",
	[73] = "CAN Combo 9 - 10.104.3.73",
	[74] = "CAN Combo 10 - 10.104.3.74",
	[75] = "CAN Combo 11 - 10.104.3.75",
	[76] = "CAN Combo 12 - 10.104.3.76",
	[77] = "CAN Combo 13 - 10.104.3.77",
	[78] = "CAN Combo 14 - 10.104.3.78",
	[79] = "CAN Combo 15 - 10.104.3.79",
	[96] = "100 High 0 - 10.104.3.96",
	[97] = "100 High 1 - 10.104.3.97",
	[98] = "100 High 2 - 10.104.3.98",
	[99] = "100 High 3 - 10.104.3.99",
	[100] = "100 High 4 - 10.104.3.100",
	[101] = "100 High 5 - 10.104.3.101",
	[102] = "100 High 6 - 10.104.3.102",
	[103] = "100 High 7 - 10.104.3.103",
	[104] = "100 High 8 - 10.104.3.104",
	[105] = "100 High 9 - 10.104.3.105",
	[106] = "100 High 10 - 10.104.3.106",
	[107] = "100 High 11 - 10.104.3.107",
	[108] = "100 High 12 - 10.104.3.108",
	[109] = "100 High 13 - 10.104.3.109",
	[110] = "100 High 14 - 10.104.3.110",
	[111] = "100 High 15 - 10.104.3.111",
	[128] = "Eth Combo 0 - 10.104.3.128",
	[129] = "Eth Combo 1 - 10.104.3.129",
	[130] = "Eth Combo 2 - 10.104.3.130",
	[131] = "Eth Combo 3 - 10.104.3.131",
	[132] = "Eth Combo 4 - 10.104.3.132",
	[133] = "Eth Combo 5 - 10.104.3.133",
	[134] = "Eth Combo 6 - 10.104.3.134",
	[135] = "Eth Combo 7 - 10.104.3.135",
	[136] = "Eth Combo 8 - 10.104.3.136",
	[137] = "Eth Combo 9 - 10.104.3.137",
	[138] = "Eth Combo 10 - 10.104.3.138",
	[139] = "Eth Combo 11 - 10.104.3.139",
	[140] = "Eth Combo 12 - 10.104.3.140",
	[141] = "Eth Combo 13 - 10.104.3.141",
	[142] = "Eth Combo 14 - 10.104.3.142",
	[143] = "Eth Combo 15 - 10.104.3.143",
	[144] = "1000 High 0 - 10.104.3.144",
	[145] = "1000 High 1 - 10.104.3.145",
	[146] = "1000 High 2 - 10.104.3.146",
	[147] = "1000 High 3 - 10.104.3.147",
	[148] = "1000 High 4 - 10.104.3.148",
	[149] = "1000 High 5 - 10.104.3.149",
	[150] = "1000 High 6 - 10.104.3.150",
	[151] = "1000 High 7 - 10.104.3.151",
	[152] = "1000 High 8 - 10.104.3.152",
	[153] = "1000 High 9 - 10.104.3.153",
	[154] = "1000 High 10 - 10.104.3.154",
	[155] = "1000 High 11 - 10.104.3.155",
	[156] = "1000 High 12 - 10.104.3.156",
	[157] = "1000 High 13 - 10.104.3.157",
	[158] = "1000 High 14 - 10.104.3.158",
	[159] = "1000 High 15 - 10.104.3.159",


	
	[192] = "SerDes Adpater (allgemein) - 10.104.3.192",
	[193] = "ADCAM low - 10.104.3.193",
	[194] = "ADCAM mid - 10.104.3.194",
	[195] = "UCAP - 10.104.3.195",
	[196] = "SerDes xPAD - 10.104.3.196",
	[197] = "SerDes xPAD - 10.104.3.197",
	[198] = "SerDes xPAD from UCAP - 10.104.3.198",
	[199] = "SerDes xPAD from ADCAM - 10.104.3.199",
	
	[200] = "SerDes LIDAR vorne - 10.104.3.200",
	[201] = "SerDes LIDAR vorne links - 10.104.3.201",
	[202] = "SerDes LIDAR vorne rechts - 10.104.3.202",
	[203] = "SerDes LIDAR hinten links - 10.104.3.203",
	[204] = "SerDes LIDAR hinten rechts - 10.104.3.204",
	[205] = "SerDes ARCAM - 110.104.3.205",
	
	[177] = "MRR-MTA-B - 10.104.3.177",
	[178] = "FRR-MTA-B - 10.104.3.178",
	
    [179] = "UCAP TIC (TestInterface Card)- V3H - 10.104.3.179",
    [180] = "UCAP TIC (TestInterface Card)- M3N - 10.104.3.179",
	[181] = "USS MTA  - 10.104.3.181",
	[16] = "Logger 1 - 10.104.3.16",
	[17] = "Logger 2 - 10.104.3.17",
	[18] = "Logger 3 - 10.104.3.18"	
		
}


local ENUM_MSG_TYPE_VAL={
	[0x0] = nil,
	[0x1] = "CAN (-FD) Raw",
	[0x2] = "CAN Data",
	[0x3] = "CAN-FD Data",
	[0x4] = "LIN Data",
	[0x7] = "Flexray Raw",
	[0x8] = "Flexray Data",
	[0xA] = "GPIO",
	[0x10] = "UART/RS232_ASCII",
	[0x11] = "UART/RS232_RAW",
	[0x12] = "UART/RS232_SLA",
	[0x20] = "Analog",
	[0x21] = "Analog_SLA",
	[0x80] = "Ethernet II (FZG-Kommunikation, incl. UDP-DLT)",
	[0xA0] = "XCP-Data",
	[0x101] = "MIPI-CSI2 Video",
	[0x102] = "MIPI-CSI2 Lidar",
	[0x103] = "SPI",
	[0x104] = "I2C 7 Bit",
	[0x200] = "TAPI",
	[0x201] = "TAPI Initial State",
	[0x202] = "TAPI Core Dump",
	[0x400] = "Radar",
	[0xA000] = "PLP_Raw",
	[0xB000] = "PreLabel"
}

local probeflags_mask = {
  [0x0001] = "EoS",
  [0x0002] = "SoS",
  [0x0004] = "Spy",
  [0x0008] = "Multi-Frame",
  [0x8000] = "Probe Overflow"
}

----------------------------------------
-- a function to convert tables of enumerated types to value-string tables
-- i.e., from { "name" = number } to { number = "name" }
local function makeValString(enumTable)
    local t = {}
    for name,num in pairs(enumTable) do
        t[num] = name
    end
    return t
end

local ENUM_MSG_TYPE_VALSTR = makeValString(ENUM_MSG_TYPE_VAL)
local ENUM_PLP_TYPE_VALSTR = makeValString(ENUM_PLP_TYPE)

local plp_proto = Proto("PLP", "PLP")
local plp_vd_proto = Proto("PLP_VD", "Vehicle Data")


--------------------------------
-- Table with fields alignment
local al_f = {
  ["plp"] = 11,
  ["probeflags"] = 14,
  ["vd_entry"] = 15,
  ["ts_b"] = 8,        -- timestamp bitmask
  ["ts"] = 20,         -- timestamp
  ["data_f"] = 25
}
----------------------------------------
-- a table of all of our Protocol's fields
local plp_header_fields =
{
   plp_probe_id = ProtoField.uint16 ("plp.probeid", _ljust("ProbeID", al_f["plp"]), base.DEC),
   plp_counter = ProtoField.uint16 ("plp.counter", _ljust("Counter", al_f["plp"]), base.DEC),
   plp_version = ProtoField.uint16 ("plp.version", _ljust("Version", al_f["plp"]), base.DEC),
   plp_type = ProtoField.uint8 ("plp.plptype", _ljust("PLPType", al_f["plp"]), base.HEX, ENUM_PLP_TYPE),
   plp_msgtype = ProtoField.uint16 ("plp.msgtype", _ljust("MsgType", al_f["plp"]), base.HEX, ENUM_MSG_TYPE_VAL),
   plp_reserved = ProtoField.uint16 ("plp.reserved", _ljust("Reserved", al_f["plp"]), base.HEX),
   plp_probeflags = ProtoField.uint16 ("plp.probeflags", _ljust("ProbeFlags", al_f["plp"]), base.HEX),
   plp_probeflags_eos = ProtoField.bool ("plp.probeflags.eos", _ljust("EoS", al_f["probeflags"]), 16, {"yes", "no"}, 0x0001, "End of Segment"),
   plp_probeflags_sos = ProtoField.bool ("plp.probeflags.sos", _ljust("SoS", al_f["probeflags"]), 16, {"yes", "no"}, 0x0002, "Start of Segment"),
   plp_probeflags_spy = ProtoField.bool ("plp.probeflags.spy", _ljust("Spy", al_f["probeflags"]), 16, {"yes", "no"}, 0x0004, "Spy"),
   plp_probeflags_multiframe = ProtoField.bool ("plp.probeflags.multiframe", _ljust("Multi-Frame", al_f["probeflags"]), 16, {"yes", "no"}, 0x0008, "Multi-Frame"),
   plp_probeflags_overflow = ProtoField.bool ("plp.probeflags.overflow", _ljust("Probe Overflow", al_f["probeflags"]), 16, {"yes", "no"}, 0x8000, "Probe Overflow"),
   vehicle_data = ProtoField.none("plp.vd", "Vehicle_Data"),
   vehicle_data_Entry = ProtoField.none("plp.vd", "Vehicle Data Entry Header", nil),
   plp_padding = ProtoField.none("plp.padding", "<< Padding >>")
}


local plp_vehicle_data_fields =
{
	busspecid = ProtoField.uint32 ("plp.vd.busspecid", _ljust("BusSpecID", al_f["vd_entry"]), base.HEX),
	-- ethernet busspecid
	eth_vlan = ProtoField.uint32("plp.vd.eth_vlan", _ljust("Eth Vlan", al_f["vd_entry"]), base.HEX, nil, 0xFFF00000, "Vlan"),
	eth_busspecid = ProtoField.uint32("plp.vd.eth_busspecid", _ljust("BusSpecID", al_f["vd_entry"]), base.HEX, nil, 0x000FFFFF, "Vlan"),
	
	timestamp_field = ProtoField.uint64("plp.vd.timestamp_field", _ljust("timestamp_field", al_f["vd_entry"]), base.HEX),
	timestamp_async = ProtoField.bool ("plp.vd.timestamp_async", _ljust("Sync?", al_f["ts_b"]), 8, {"Asynchronous", "Synchronous or standalone"}, 0x80, "Asynchronous?"),
	timestamp_reserved = ProtoField.bool ("plp.vd.timestamp_reserved", _ljust("Reserved", al_f["ts_b"]), 8, nil, 0x40, "Reserved"),
	timestamp_val = ProtoField.uint64("plp.vd.timestamp_val", _ljust("timestamp_val", al_f["ts"]), base.DEC),
	timestamp = ProtoField.absolute_time ("plp.vd.timestamp", _ljust("Timestamp", al_f["ts"])),
	length = ProtoField.uint16("plp.vd.length", _ljust("Length", al_f["vd_entry"]), base.DEC),
	dv_dataflags = ProtoField.uint16 ("plp.vd.dataflags", _ljust("DataFlags", al_f["vd_entry"]), base.HEX),
	
	-- LIN Data Flags
	dv_lin_dataflags_collision_error = ProtoField.bool ("plp.vd.lin_collision", _ljust("Collision error", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "Collision error"),
	dv_lin_dataflags_parity_error = ProtoField.bool ("plp.vd.lin_parity_error", _ljust("Parity error", al_f["data_f"]), 16, {"yes", "no"}, 0x0002, "Parity error"),
    dv_lin_dataflags_slave_no_resp = ProtoField.bool ("plp.vd.lin_slave_no_resp", _ljust("No slave response", al_f["data_f"]), 16, {"yes", "no"}, 0x0004, "No slave response"),
	
	-- CAN Data Flags
	dv_can_dataflags_ack = ProtoField.bool ("plp.vd.can_ack", _ljust("ACK", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "ACK"),
	dv_can_dataflags_rtr = ProtoField.bool ("plp.vd.can_rtr", _ljust("RTR", al_f["data_f"]), 16, {"yes", "no"}, 0x0002, "RTR"),
	dv_can_dataflags_ide = ProtoField.bool ("plp.vd.can_ide", _ljust("IDE", al_f["data_f"]), 16, {"yes", "no"}, 0x0004, "IDE"),
    dv_can_dataflags_err = ProtoField.bool ("plp.vd.can_err", _ljust("ERR", al_f["data_f"]), 16, {"yes", "no"}, 0x0008, "ERR"),
	
	-- CAN FD Data Flags
	dv_canfd_dataflags_ack = ProtoField.bool ("plp.vd.canfd_ack", _ljust("ACK", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "ACK"),
	dv_canfd_dataflags_esi = ProtoField.bool ("plp.vd.canfd_esi", _ljust("ESI", al_f["data_f"]), 16, {"yes", "no"}, 0x0002, "ESI"),
	dv_canfd_dataflags_ide = ProtoField.bool ("plp.vd.canfd_ide", _ljust("IDE", al_f["data_f"]), 16, {"yes", "no"}, 0x0004, "IDE"),
    dv_canfd_dataflags_err = ProtoField.bool ("plp.vd.canfd_err", _ljust("ERR", al_f["data_f"]), 16, {"yes", "no"}, 0x0008, "ERR"),	
	dv_canfd_dataflags_brs = ProtoField.bool ("plp.vd.canfd_brs", _ljust("BRS", al_f["data_f"]), 16, {"yes", "no"}, 0x0010, "ERR"),
 
	-- Flexray Data Flags
	dv_flexray_dataflags_nf = ProtoField.bool ("plp.vd.fr_nf", _ljust("NF", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "Null Frame"),
	dv_flexray_dataflags_sf = ProtoField.bool ("plp.vd.fr_sf", _ljust("SF", al_f["data_f"]), 16, {"yes", "no"}, 0x0002, "Startup Frame"),
	dv_flexray_dataflags_sync = ProtoField.bool ("plp.vd.fr_sync", _ljust("Sync", al_f["data_f"]), 16, {"yes", "no"}, 0x0004, "Sync Frame"),
	dv_flexray_dataflags_wus = ProtoField.bool ("plp.vd.fr_wup", _ljust("WUS", al_f["data_f"]), 16, {"yes", "no"}, 0x0008, "WUS"),
    dv_flexray_dataflags_ppi = ProtoField.bool ("plp.vd.fr_ppi", _ljust("PPI", al_f["data_f"]), 16, {"yes", "no"}, 0x0010, "Payload Preamble Indicator"),
	
	-- RS232 Data Flags
	dv_rs232_dataflags_parity = ProtoField.bool ("plp.vd.rs232_parity", _ljust("ParityError", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "Parity error"),
	dv_rs232_dataflags_dl = ProtoField.uint16 ("plp.vd.rs232_dl", _ljust("DL", al_f["data_f"]), base.HEX, RS232_bits, 0x000E, "Number of RS232 bits"),

	-- Analog Data Flags
	dv_analog_dataflags_thr_e = ProtoField.bool ("plp.vd.analog_thr_e", _ljust("Threshold Exceeded", al_f["data_f"]), 16, {"yes", "no"}, 0x0001, "Threshold Exceeded"),
	dv_analog_dataflags_thr_u = ProtoField.bool ("plp.vd.analog_thr_u", _ljust("Threshold Undershot", al_f["data_f"]), 16, {"yes", "no"}, 0x0002, "Threshold Undershot"),
	dv_analog_dataflags_unit = ProtoField.uint16 ("plp.vd.analog_unit", _ljust("Unit", al_f["data_f"]), base.HEX, analog_unit, 0x000C, "Unit"),
	dv_analog_dataflags_factor = ProtoField.uint16 ("plp.vd.analog_factor", _ljust("Factor", al_f["data_f"]), base.HEX, analog_factor, 0x0180, "Factor"),
	dv_analog_dataflags_sample_time = ProtoField.uint16 ("plp.vd.analog_sample_time", _ljust("Sample Time", al_f["data_f"]), base.HEX, analog_sample_time, 0x7800, "Sample Time"),
	
	-- General Data Flags
	dv_dataflags_crc_error = ProtoField.bool ("plp.vd.crc_error", _ljust("CRC error", al_f["data_f"]), 16, {"yes", "no"}, 0x2000, "CRC error"),
	dv_dataflags_tx = ProtoField.bool ("plp.vd.tx", _ljust("TX (probe as transmitter)", al_f["data_f"]), 16, {"yes", "no"}, 0x4000, "TX (probe as transmitter)"),
	dv_dataflags_overflow = ProtoField.bool ("plp.vd.overflow", _ljust("Overflow", al_f["data_f"]), 16, {"yes", "no"}, 0x8000, "Overflow"),
	
	data_flags = ProtoField.uint16 ("plp.dataflags", "DataFlags", base.HEX),
}


-- register the ProtoFields
plp_proto.fields = plp_header_fields
plp_vd_proto.fields = plp_vehicle_data_fields

local tvbs = {}

---------------------------------------
-- This function will be invoked by Wireshark during initialization, such as
-- at program start and loading a new file
function plp_proto.init()
    -- reset the save Tvbs
    tvbs = {}
end

local vd_counter = 0

local table_plp = DissectorTable.new("plp", "plp")
local table_plp_type = DissectorTable.new("plp.type", "plp.type")

local src_mac_address_field = Field.new("eth.src")


function plp_proto.dissector(tvbuf, pktinfo, root)
    -- reset the save Tvbs
    tvbs = {}
	-- sort help table
	table.sort(probeflags_mask)
	
	-- some offsets	
	O_PLP_PROBE_ID = 0
	O_PLP_COUNTER = 2
	O_PLP_VERSION = 4
	O_PLP_TYPE = 5
	O_PLP_MSGTYPE = 6	
	O_PLP_RESERVED = 8
	O_PLP_FLAGS_H = 10
	O_PLP_FLAGS_L = 11
	
	-- get device MAC address, required for status messages
	src_mac_address = string.sub(src_mac_address_field().label,-11)

	-- get the length of the packet buffer (Tvb).
    local pktlen = tvbuf:len()

    local bytes_consumed = 0
	vd_counter = 0
	
	-- We start by adding our protocol to the dissection display tree.
	local plp_tree = root:add(plp_proto, tvbuf:range(bytes_consumed, pktlen))
	
	-- dissect the probe_id field (2 bytes)
	local probe_id_val = tvbuf:range(bytes_consumed + O_PLP_PROBE_ID, 2):uint()
	local probe_id_node = plp_tree:add(plp_header_fields.plp_probe_id, tvbuf:range(bytes_consumed + O_PLP_PROBE_ID, 2))
	enum_plp_probe_id = PLP_PROBE_ID[probe_id_val]
	if enum_plp_probe_id ~= nil then
		probe_id_node:append_text(" ("..enum_plp_probe_id..")")
	end
	
	--dissect the counter field (2 bytes)
	plp_tree:add(plp_header_fields.plp_counter, tvbuf:range(bytes_consumed + O_PLP_COUNTER, 2))
	
	--dissect the plp version field (1 byte)
	plp_tree:add(plp_header_fields.plp_version, tvbuf:range(bytes_consumed + O_PLP_VERSION, 1))
	
	-- dissect the plp type field (1 byte)
	local plp_type_val = tvbuf:range(bytes_consumed + O_PLP_TYPE, 1):uint()
	plp_tree:add(plp_header_fields.plp_type, tvbuf:range(bytes_consumed + O_PLP_TYPE, 1))
	
	-- dissect the msgtype field
	local msg_type_val = tvbuf:range(bytes_consumed + O_PLP_MSGTYPE,2):uint()
	plp_tree:add(plp_header_fields.plp_msgtype, tvbuf:range(bytes_consumed + O_PLP_MSGTYPE, 2))
	
	-- dissect the reserved bytes (2 bytes)
	if (DEFAULT_SETTINGS.show_reserved_bytes_in_plp_header == true) then
		plp_tree:add(plp_header_fields.plp_reserved, tvbuf:range(bytes_consumed + O_PLP_RESERVED, 2))
	end
	
	-- dissect the probe flags (2 bytes)
	local flags_tree = plp_tree:add(plp_header_fields.plp_probeflags, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	flags_tree:add(plp_header_fields.plp_probeflags_eos, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	flags_tree:add(plp_header_fields.plp_probeflags_sos, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	flags_tree:add(plp_header_fields.plp_probeflags_spy, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	flags_tree:add(plp_header_fields.plp_probeflags_multiframe, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	flags_tree:add(plp_header_fields.plp_probeflags_overflow, tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2))
	
	-- get a str to show a summary of all flags
    local mask = tvbuf:range(bytes_consumed + O_PLP_FLAGS_H, 2):uint()
	str_flags = getStrFlags(mask)
	flags_tree:append_text(str_flags)

	-- update bytes_consumed
	bytes_consumed = bytes_consumed + DEFAULT_SETTINGS.PLP_HEADER_LENGTH	
	
	while bytes_consumed < pktlen do
		-- we pass vd_tree which is the root of all vehicle data entries
		local result = dissectVehicleData(tvbuf, 
										  pktinfo, 
										  root,
										  bytes_consumed,
										  msg_type_val,  -- needed to call subdissectors
										  plp_type_val)  -- 
		
		if result > 0 then
			bytes_consumed = bytes_consumed + result
		elseif result < 0 then
			bytes_consumed = bytes_consumed - result
		elseif result == 0 then
			-- If the result is 0, then it means we hit an error of some kind,
			-- so return 0. Returning 0 tells Wireshark this packet is not for
			-- us, and it will try heuristic dissectors or the plain "data"
			-- one, which is what should happen in this case.
			return 0
		end
	end
	
	-- We set the column Info and Protocol at the end of the dissection to be sure 
	-- we overwrite any info from other dissectors.
	-- For example with Ethernet:
	
	-- set the INFO column for this frame/packet
	set_info_column(pktinfo, msg_type_val, probe_id_val, plp_type_val)	
	
	-- set the protocol column to show our protocol name
    pktinfo.cols.protocol:set("PLP "..dissector_proto_version)
end


set_info_column = function (pktinfo, msg_type_val, probe_id_val, plp_type_val)
    str_info_column = "PLP ("..ENUM_PLP_TYPE[plp_type_val]..")"
    
	if ENUM_MSG_TYPE_VAL[msg_type_val] then
        str_info_column = str_info_column.."("..ENUM_MSG_TYPE_VAL[msg_type_val]..")"
	end	
	
	if PLP_PROBE_ID[probe_id_val] then
        str_info_column = str_info_column.." ("..PLP_PROBE_ID[probe_id_val]..")"
	end
    pktinfo.cols.info:set(str_info_column)

end


getStrFlags = function(mask)
	local flags_info = ""
	for flag_mask,flag_str in pairs(probeflags_mask) do
		if bit.band(mask, flag_mask) == flag_mask then
			flags_info = flags_info.." ["..flag_str.."]"
		end
	end
	return flags_info
end


-----------------------------------
-- This function converts the timestamp from nanosecs from the Epoch to Time
-- 
-- param nsecs_raw_h: high value from the number of nanosecs
-- param nsecs_raw_l: low value from the number of nanosecs
get_nstime = function(nsecs_raw_h, nsecs_raw_l)
	-- https://osqa-ask.wireshark.org/questions/45308/convert-us-timestamp-to-absolute_time
	-- First two bits should be ignored. Bitwise operation limited to 32bits
	local nsecs_h = bit.band(nsecs_raw_h, 0x3FFFFFFF)
	local total_nsecs = UInt64(nsecs_raw_l, nsecs_h)
	
	secs  = (total_nsecs / 1000000000):tonumber()
	nsecs = (total_nsecs % 1000000000):tonumber()
	_nstime = NSTime.new(secs, nsecs)
	return _nstime, total_nsecs
end

----------------------------------------
-- The function to check the length field.
--
-- This returns two things: is dissection of Vehicle Data possible? and the length of bytes remaining in Tvb buffer
checkVDLength = function (tvbuf, offset)
    -- "msglen" is the number of bytes remaining in the Tvb buffer which we
    -- have available to dissect in this run
    local msglen = tvbuf:len() - offset
	
	if msglen <= DEFAULT_SETTINGS.VD_HDR_LEN then
		return false, msglen
	else
		return true, msglen
	end	
end

checkPaddingAndCrc = function (tvbuf, root, offset)
	local padding = root:add(plp_header_fields.plp_padding, tvbuf:range(offset))

	-- Now we analyze if the padding contains also CRC at the end
	-- If less than 4 bytes, clearly no CRC at the end
	if padding.len >= 4 then
		local possible_crc = tvbuf:range(tvbuf:len() - 4):uint()
		-- Assumption: CRC is identified when last 4 bytes are != 0, although 0 would be also a valid CRC
		-- The probability to get a CRC = 0 is quite low, and otherwise we have no way to identify the CRC without complicating too much the code
		if possible_crc ~= 0 then -- It has CRC
			if padding.len == 4 then -- Only CRC, no actual padding
				padding:set_text("<< CRC (0x"..string.format("%x", possible_crc)..") >>")
			else -- Padding + CRC
				padding:set_text("<< Padding with CRC (0x"..string.format("%x", possible_crc)..") >>")
			end
		end
	end
	
end

dissectVehicleData = function (tvbuf, pktinfo, root, offset, msg_type_val, plp_type)

	-- some offsets
	local O_BUS_SPEC_ID = 0
	local O_TS_H = 4
	local O_TS_L = 8
	local O_LENGTH = 12
	local O_DATA_FLAGS = 14
	local O_SOURCE_DATA = 16
	
	-- Initial check: is there potentially a new VDE ?
	-- => Minimum amount of bytes left, at least >= VDE header length
	local dissect_possible, rest_bytes = checkVDLength(tvbuf, offset)
	if not dissect_possible then
		
		checkPaddingAndCrc(tvbuf, root, offset)		
		return -rest_bytes
	end

	
	-- Dissect the length of the vehicle data
	local vd_length = tvbuf:range(offset + O_LENGTH, 2)
	local vd_length_val = tvbuf:range(offset + O_LENGTH, 2):uint()
	local remaining_bytes = tvbuf:len() - offset - DEFAULT_SETTINGS.VD_HDR_LEN

	-- First check: is this really a VDE or just padding? If busspecID == 0, no VDE
	-- Second check: are there so many remaining bytes as stated in the VDE length field? If not, no VDE
	local busspecid_val = tvbuf:range(offset + O_BUS_SPEC_ID, 4):uint()
    if busspecid_val == 0 or vd_length_val > remaining_bytes then
		checkPaddingAndCrc(tvbuf, root, offset)
		return -rest_bytes
	end
	
	-- At this point we know that we have a VDE ahead that needs to be decided
	
	-- increment the counter of VDEs
	vd_counter = vd_counter + 1
	
	-- create single vehicle data
	local single_vd = root:add(plp_header_fields.vehicle_data_Entry, tvbuf(offset, DEFAULT_SETTINGS.VD_HDR_LEN))
	single_vd:append_text(" ("..vd_counter..")")
	
	-- dissect busspecid field. Special case for ethernet
	if (msg_type_val == ENUM_MSG_TYPE_VALSTR["Ethernet II (FZG-Kommunikation, incl. UDP-DLT)"]) then
		single_vd:add(plp_vehicle_data_fields.eth_vlan, tvbuf:range(offset + O_BUS_SPEC_ID, 4))
		single_vd:add(plp_vehicle_data_fields.eth_busspecid, tvbuf:range(offset + O_BUS_SPEC_ID, 4))
	else	
		local busspecid = tvbuf:range(offset + O_BUS_SPEC_ID, 4)
		single_vd:add(plp_vehicle_data_fields.busspecid, busspecid)
	end
	
	-- create timestamp tree
	local timestamp_field = single_vd:add(plp_vehicle_data_fields.timestamp_field, tvbuf:range(offset + O_TS_H, 8))
	
	-- dissect the Time is Asynchronous bit.
	timestamp_field:add(plp_vehicle_data_fields.timestamp_async, tvbuf:range(offset + O_TS_H, 1))	
	timestamp_field:add(plp_vehicle_data_fields.timestamp_reserved, tvbuf:range(offset + O_TS_H, 1))	
	
	nsecs_raw_h = tvbuf:range(offset + O_TS_H, 4):uint()
	nsecs_raw_l = tvbuf:range(offset + O_TS_L, 4):uint()
	nstime, timestamp_val = get_nstime(nsecs_raw_h, nsecs_raw_l)
	timestamp_field:add(plp_vehicle_data_fields.timestamp_val, tvbuf:range(offset + 4, 8), timestamp_val)
	timestamp_field:add(plp_vehicle_data_fields.timestamp, tvbuf:range(offset + 4, 8),nstime)	
	
	-- add the length
	single_vd:add(plp_vehicle_data_fields.length, vd_length)
	
	-- dissect the flags
	dissect_vd_flags(tvbuf, pktinfo, single_vd, offset + O_DATA_FLAGS, msg_type_val)
	
	-- dissect source data
	if vd_length_val > 0 then

		local newtvb = tvbuf(offset + O_SOURCE_DATA,vd_length_val):tvb()
		local newtvb_with_probe_flags = tvbuf(offset + O_DATA_FLAGS,vd_length_val + 2 ):tvb()
		
		if plp_type == ENUM_PLP_TYPE_VALSTR["StatusProbe"] or 
		   plp_type == ENUM_PLP_TYPE_VALSTR["StatusBus"] or
		   plp_type == ENUM_PLP_TYPE_VALSTR["StatusConfig"] or
           plp_type == ENUM_PLP_TYPE_VALSTR["UserEvent"] then
			table_plp_type:try(plp_type, newtvb, pktinfo, root)

		-- There is a special case in the analog data. Since we need the flags directly
		-- to show the values properly (unit + factor). We decided to keep the dissector
		-- in a separated file but passing the flags-bytes in this special case.
		-- special case where we need the new buffer with the flags
		elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["Analog"] then
			table_plp:try(msg_type_val, newtvb_with_probe_flags, pktinfo, root)
        
        -- CAN and CAN-FD also special cases. Needed for ERR frame.
        elseif msg_type_val == 	ENUM_MSG_TYPE_VALSTR["CAN Data"] or
               msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN-FD Data"] then
            table_plp:try(msg_type_val, newtvb_with_probe_flags, pktinfo, root)

		-- MIPI CSI-2 need access to Probe Flags
		elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["MIPI-CSI2 Video"] then
			table_plp:try(msg_type_val, tvbuf, pktinfo, root)
		else		
			table_plp:try(msg_type_val, newtvb, pktinfo, root)
		end
	end
	
	
	return DEFAULT_SETTINGS.VD_HDR_LEN + vd_length_val
end


dissect_vd_flags = function (tvbuf, pktinfo, root, offset, msg_type_val)
	local vd_dataflags_tree = root:add(plp_vehicle_data_fields.dv_dataflags, tvbuf:range(offset, 2))

	if msg_type_val ==  ENUM_MSG_TYPE_VALSTR["LIN Data"] then
		-- add the lin flags
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_lin_dataflags_collision_error, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_lin_dataflags_parity_error, tvbuf:range(offset, 2))
        vd_dataflags_tree:add(plp_vehicle_data_fields.dv_lin_dataflags_slave_no_resp, tvbuf:range(offset, 2))
	elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN Data"] then
		-- add the can flags
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_can_dataflags_ack, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_can_dataflags_rtr, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_can_dataflags_ide, tvbuf:range(offset, 2))
        vd_dataflags_tree:add(plp_vehicle_data_fields.dv_can_dataflags_err, tvbuf:range(offset, 2))
	elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN-FD Data"] then
		-- add the can-fd flags
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_canfd_dataflags_ack, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_canfd_dataflags_esi, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_canfd_dataflags_ide, tvbuf:range(offset, 2))
        vd_dataflags_tree:add(plp_vehicle_data_fields.dv_canfd_dataflags_err, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_canfd_dataflags_brs, tvbuf:range(offset, 2))
		
	elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["Flexray Data"] then
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_flexray_dataflags_nf, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_flexray_dataflags_sf, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_flexray_dataflags_sync, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_flexray_dataflags_wus, tvbuf:range(offset, 2))
        vd_dataflags_tree:add(plp_vehicle_data_fields.dv_flexray_dataflags_ppi, tvbuf:range(offset, 2))
	elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["UART/RS232_ASCII"] or 
		   msg_type_val == ENUM_MSG_TYPE_VALSTR["UART/RS232_RAW"] then
		--add the uart/rs232 flags
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_rs232_dataflags_parity,tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_rs232_dataflags_dl,tvbuf:range(offset, 2))
	elseif msg_type_val == ENUM_MSG_TYPE_VALSTR["Analog"] then	
		-- add the analog flags
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_analog_dataflags_thr_e, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_analog_dataflags_thr_u, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_analog_dataflags_unit, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_analog_dataflags_factor, tvbuf:range(offset, 2))
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_analog_dataflags_sample_time, tvbuf:range(offset, 2))		
	end
	
	if msg_type_val ==  ENUM_MSG_TYPE_VALSTR["LIN Data"] or
	   msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN Data"] or
	   msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN-FD Data"] or 
	   msg_type_val == ENUM_MSG_TYPE_VALSTR["CAN (-FD) Raw"] or
	   msg_type_val == ENUM_MSG_TYPE_VALSTR["Flexray Data"] or
	   msg_type_val == ENUM_MSG_TYPE_VALSTR["Ethernet II (FZG-Kommunikation, incl. UDP-DLT)"] then
	   
	   vd_dataflags_tree:add(plp_vehicle_data_fields.dv_dataflags_crc_error, tvbuf:range(offset, 2))
	end
	
	if msg_type_val ~=  ENUM_MSG_TYPE_VALSTR["Analog"] then
		vd_dataflags_tree:add(plp_vehicle_data_fields.dv_dataflags_tx, tvbuf:range(offset, 2))
	end
	
	vd_dataflags_tree:add(plp_vehicle_data_fields.dv_dataflags_overflow, tvbuf:range(offset, 2))
end
--------------------------------------------------------------------------------
-- We want to have our protocol dissection invoked for a specific ether_type,
-- so get the TCP dissector table and add our protocol to it.
local function enableDissector()	
	ether_table = DissectorTable.get("ethertype")
	ether_table:add(DEFAULT_SETTINGS.port, plp_proto)
	ether_table:add(DEFAULT_SETTINGS.port_alt, plp_proto)
end

if DEFAULT_SETTINGS.enabled == true then
	enableDissector()
end


									