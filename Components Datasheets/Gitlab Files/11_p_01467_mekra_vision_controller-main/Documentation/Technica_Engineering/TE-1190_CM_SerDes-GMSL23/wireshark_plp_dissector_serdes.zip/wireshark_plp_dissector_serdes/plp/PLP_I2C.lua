-------------------------------------------------------------------
-- PLP Lua dissector
--
-- PLP I2C protocol dissector. 
-- Currently is supporting a single I2C transaction per PLP frame.
--
-- @author: Guillem Prats
-------------------------------------------------------------------

-- enums
local control_characters = {
	[0x00] = "NACK",
	[0x01] = "ACK",
	[0x02] = "STOP",
	[0x03] = "REPEATED START"
}

do
	-- Create a new dissector
	I2C_PROTO = Proto("PLP_I2C", "PLP I2C")
	const_i2c_MsgType = 0x0104

	-- Table for all i2c fields
	local plp_i2c_fields = {
		i2c_address = ProtoField.uint8 ("plp.i2c_address", _ljust("I2C Address", 13), base.HEX),
		i2c_slave_address = ProtoField.uint8 ("plp.i2c_slave_address", _ljust("I2C Slave Address (7-bit)", 13), base.HEX),
		i2c_read_write = ProtoField.bool("plp.i2c_wr", _ljust("I2C R/W", 8), 8, {"Read", "Write"}, 0x01),
		i2c_control_char = ProtoField.uint8("plp.i2c_control_char", _ljust("Control character", 13), base.HEX, control_characters),
		i2c_data_byte = ProtoField.uint8("plp.i2c_data_byte", _ljust("Data Byte", 13), base.HEX)
	}

	-- Register the ProtoFields
	I2C_PROTO.fields = plp_i2c_fields

	-- The dissector function
	function I2C_PROTO.dissector (buffer, pinfo, tree)
		length = buffer:len()
		if length == 0 then return end

		-- Adding fields to the tree
		local plp_i2c_tree = tree:add(I2C_PROTO, buffer())
		local is_first_byte = true
		local is_command_byte = false
		local number_bytes = buffer:len()

		for i = 0,number_bytes-1, 1 do
			if is_first_byte then
				local i2c_address_tree = plp_i2c_tree:add(plp_i2c_fields.i2c_address, buffer:range(i, 1))
				i2c_address_tree:add(plp_i2c_fields.i2c_slave_address, bit.rshift(buffer:range(i, 1):uint(),1))
				i2c_address_tree:add(plp_i2c_fields.i2c_read_write, buffer:range(i, 1))
				is_first_byte = false
				is_command_byte = true
			elseif is_command_byte then
				plp_i2c_tree:add(plp_i2c_fields.i2c_control_char, buffer:range(i, 1))
				is_command_byte = false
			else
				plp_i2c_tree:add(plp_i2c_fields.i2c_data_byte, buffer:range(i, 1))
				is_command_byte = true
			end
		end
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_i2c_MsgType, I2C_PROTO)
end