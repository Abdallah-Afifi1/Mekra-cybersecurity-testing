Changelog

** Release 9.0.0 **
  - Added PLP I2C dissector
  - Added PLP GPIO dissector
  - Added PLP MIPI dissector (only for FS and Metadata chunks).
  - Upadted dissector for Status Messages to support PLP SerDes vartiants. 


** Release 8.6.2 **
  - Dissection of StatusConfig has been adapted to the new proposal.

** Release 8.6.1 **
  - Updated dissection in PLP_VendorSpecificConfig_Technica to the new version (segmented config)
  - Updated Capture module names
  - Added linkup time in VendorData
  - (VTS-282) Added bit flag BRS in CAN-FD
  - Small improvements in representation and visualization

** Release 8.5 **
  - Added workaround to minimize the impact of the spec issue of wrong UDP port for config messages (port 30491 generates a conflict with SOME/IP)

** Release 8.4 **
  - Added new EtherType 0x99FE
  - Changed Buffer Fill Level to decimal in Status Probe
  - Fixed parsing from VendorSpecific in Status Bus

** Release 8.3 **
  - Fixed issue with interpretation of CAN-FD messages with ESI flag activated

** Release 8.2 **
  - Fixed filter name for FlexRay data flags
  - Updated dissector version

** Release 8.1 **
  - Fixed error interpreting VDE when frame contains padding
  - Added new coloring rules

** Release 8.0 **
  - Fixed interpretation of CAN(-FD) error frames
  - Added support for (de)packetization

** Release 7.0 **
No changes

** Release 6.6 **
  - Added interpretation of CAN error frames different from CAN(-FD) data frames
  - Updated representation of padding to reflect the presence of CRC added by Linux-based devices like X2E or ViGEM data loggers
  - Removed word "protocol" from description of the different PLP message types (CAN, LIN, FR...) to keep consistency with other Ethernet dissectors

** Release 6.5 **
  - Added support for PLP UE messages
  - Added support for UDP messages (UE, Discovery, Configuration)
    - NOTE: Currently there is a conflict in the interpretation of Configuration messages if SOME/IP and PLP dissectors are being used in Wireshark, due to same UDP port used for both UDP messages. This can only be solved after a change in the specs and the subsequent update of the firmware. In the meantime, please use the option "decode as" for the UDP Configuration messages
  - Added representation of padding in short messages

** Release 5.5 **
  - Adapted dissector to PLP version 2 (PLP specs v3.3)
  - Fixed issue with decoding probe serial number
  - Removed "BMW dissector version..." from the vehicle data tree info. Added into the protocol column instead
  - Fixed data flag names on Flexray

** Release 3.5 ** 
  -	Fixed problem where the dissectors were sometimes not loading properly.
  -	Added a init.lua file which defines the order to load the different dissector files.
  -	New method to install the plugins. See this readme.txt
  - Fixed PLP-LIN dissector where it was trying to dissect checksum also when there was no payload.
  - Added identification error frames in CAN: (can_id == 0x00)?
  - Added dissection of vendor specific for: "status configuration", "status bus" and "status probe"
  - Added dissection of user events


To install this dissector copy the two folders under your personal configuration folder.

Windows
-------
%APPDATA%\Wireshark\
   |-- plugins/
              |-- init.lua
   |-- plp/
          |-- plp.lua          
          |-- PLP_ANALOG.lua
          |-- ...
          |-- PLP_STATUS_PROBE.lua

Linux
-------
~/.config/wireshark/
   |-- plugins/
              |-- init.lua
   |-- plp/
          |-- plp.lua          
          |-- PLP_ANALOG.lua
          |-- ...
          |-- PLP_STATUS_PROBE.lua
          
  