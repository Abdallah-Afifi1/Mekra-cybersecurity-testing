-- @change me:
dissector_proto_version = "[Dissector v8.3.0]"

local PLP_UE_ID = {
    [0x0002] = "Logger Ready",    
    [0x0004] = "Logger Shut Down",
    [0x0100] = "Range ADCAM Low",
    [0x01FF] = "Range ADCAM Low",
    [0x0101] = "ADCAM Low Bus Data Vali-dation Failed",
    [0x0102] = "ADACM Low Raw Data Vali-dation Failed",
    [0x0103] = "ADCAM Low ECU Error / HW Reset",
    [0x0104] = "ADCAM Low Sensors Blind",
    [0x0200] = "Range ADCAM MID",
    [0x02FF] = "Range ADCAM MID",
    [0x0300] = "Range ADCAM High / hPad",
    [0x03FF] = "Range ADCAM High / hPad",
    [0x0400] = "Range UCAP",
    [0x04FF] = "Range UCAP",
    [0x0500] = "Range USS",
    [0x05FF] = "Range USS",
    [0x0600] = "Range SRR",
    [0x06FF] = "Range SRR",
    [0x0700] = "Range MRR",
    [0x07FF] = "Range MRR",
    [0x0800] = "Range FRR",
    [0x08FF] = "Range FRR",
    [0x0900] = "Range LIDAR",
    [0x09FF] = "Range LIDAR"

}

local PLP_VENDOR_ID = {
    [0x04] = "AeD",
    [0x08] = "Conti",
    [0x0C] = "Technica",
    [0x10] = "ViGEM",
    [0x14] = "X2E",
    [0x20] = "Magna",
    [0x22] = "Valeo",
    [0x24] = "Aptiv"
}

local PLP_PROBE_TYPE = {
	[0x02] = "CM LIN Combo",
	[0x04] = "CM CAN Combo",
	[0x06] = "CM 100 High",
	[0x08] = "CM Eth Combo",
	[0x0A] = "CM 1000 High",
	[0x10] = "SensorSpezifisch",
	[0x20] = "Logger",
    [0x40] = "CM Serdes GMSL2/3"
}

local UDP_CONFIG_PORT = 30491
---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
    CHARACTER_TO_FILL = " "
    str_len = string.len(str)
    
    if str_len >= final_len then
        return str
    end
    len_to_fill = final_len - str_len
    return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
    
end

--------------------------------
-- Table with fields alignment
local al_f = {
  ["udp_msg"] = 42,
  ["udp_msg_options"] = 47
}

local ENUM_OPERATION = {
    [0x0002] = "Configuration mode",
    [0x0003] = "Set IP address",
    [0x0004] = "Set Multicast MAC address",
    [0x0006] = "Get probe info request",
    [0x0007] = "Get probe info response - Probe HW info",
    [0x0008] = "Get probe info response - Probe Logging interface",
}

----------------------------------------
-- a function to convert tables of enumerated types to value-string tables
-- i.e., from { "name" = number } to { number = "name" }
local function makeValString(enumTable)
    local t = {}
    for name,num in pairs(enumTable) do
        t[num] = name
    end
    return t
end

local ENUM_MSG_TYPE_STRVAL = makeValString(ENUM_OPERATION)

do
    -- description of PLP UDP Operation message
    local P_UDP_CONFIG_MSG = Proto("PLP_UDP_CONFIG", "(PLP) UDP Configuration")

    -- Create the protocol fields
    local f = P_UDP_CONFIG_MSG.fields
    
    f.version = ProtoField.uint16("plp_udp_config.version", 
                                    _ljust("version", al_f["udp_msg"]), 
                                    base.HEX)    
    f.operation = ProtoField.uint16("plp_udp_config.operation", 
                                _ljust("Operation", al_f["udp_msg"]), 
                                base.HEX, 
                                ENUM_OPERATION)
    f.length = ProtoField.uint32("plp_udp_config.length", 
                                _ljust('Length of "Options" field in bytes',
                                al_f["udp_msg"]), 
                                base.DEC)                                
    f.options = ProtoField.bytes("plp_udp_config.options", 
                                _ljust("Options",
                                al_f["udp_msg"]), 
                                base.NONE) 
    f.options_userevent_probe_id = ProtoField.uint16("plp_udp_config.options.probe_id", 
                                    _ljust("Probe ID", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)
    f.options_userevent_ue_id = ProtoField.uint16("plp_udp_config.options.ue_id", 
                                    _ljust("User Event ID", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)
    f.options_disc_resp_src_mac = ProtoField.uint64("plp_udp_config.options.src_mac", 
                                    _ljust("Source MAC address", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)
    f.options_disc_resp_src_ip = ProtoField.uint32("plp_udp_config.options.src_ip", 
                                    _ljust("Source IP address", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)  
    f.options_disc_resp_mc_mac = ProtoField.uint64("plp_udp_config.options.mc_mac", 
                                    _ljust("Multicast MAC address", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)  
    f.options_disc_resp_dst_ip = ProtoField.uint32("plp_udp_config.options.dst_ip", 
                                    _ljust("Destination IP address", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)  
    f.options_disc_resp_probe_id = ProtoField.uint32("plp_udp_config.options.probe_id", 
                                    _ljust("Probe ID", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)  
    f.options_disc_resp_probe_fw = ProtoField.uint32("plp_udp_config.options.probe_fw", 
                                    _ljust("Probe FW version", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)   
    f.options_probe_info_vendor_id = ProtoField.uint8("plp_udp_config.options.vendor_id", 
                                    _ljust("Probe Vendor ID", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)   
    f.options_probe_info_probe_type = ProtoField.uint8("plp_udp_config.options.probe_type", 
                                    _ljust("Probe Type", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)   
    f.options_probe_info_probe_serial = ProtoField.uint32("plp_udp_config.options.probe_serial", 
                                    _ljust("Probe Serial Number", 
                                    al_f["udp_msg_options"]), 
                                    base.HEX)   
    f.options_probe_info_eth_port_count = ProtoField.uint8("plp_udp_config.options.eth_port_count", 
                                    _ljust("Eth Port Count", 
                                    al_f["udp_msg_options"]), 
                                    base.DEC)  
    f.operation = ProtoField.uint16("plp_udp_config.operation", 
                                _ljust("Operation", al_f["udp_msg"]), 
                                base.HEX, 
                                ENUM_OPERATION)
    f.reserved = ProtoField.bytes("plp_udp_config.reserved", 
                                _ljust("Reserved",
                                al_f["udp_msg"]), 
                                base.NONE)
                                
                                    -- Dissector function
    function P_UDP_CONFIG_MSG.dissector(buffer, pinfo, tree)
        -- We are only dealing with a (PLP) UDP Config message if both src and dst ports are set to 30491
        if not (pinfo.src_port == UDP_CONFIG_PORT and pinfo.dst_port == UDP_CONFIG_PORT) then
            return 0;  --lets wireshark know nothing was dissected, other dissectors can be called
        end
        -- set the protocol column to show our protocol name
        pinfo.cols.protocol:set("PLP "..dissector_proto_version)
        
        -- set the INFO column for this frame/packet
        pinfo.cols.info:set("UDP tbd")
        
        -- some offsets 
        O_VERSION = 0
        O_OPERATION = 2
        O_LENGTH = 4
        O_OPTIONS = 8

        -- -- Offsets for Get Probe Info response (HW) messages
        O_OPTIONS_INFO_VENDOR_ID = 0
        O_OPTIONS_INFO_PROBE_TYPE = 1
        O_OPTIONS_INFO_PROBE_SERIAL = 2
        O_OPTIONS_INFO_ETH_PORT_COUNT = 6
        -- -- Offsets for Get Probe Info response (Logging) messages
        O_OPTIONS_INFO_BUS_IFACE_COUNT = 0
        O_OPTIONS_INFO_BUS_IFACE_ID = 2
        O_OPTIONS_INFO_BUS_MSG_TYPE = 4
        O_OPTIONS_INFO_BUS_SPEC_ID = 6
                
        -- Adding fields to the tree
        local udp_tree = tree:add (P_UDP_CONFIG_MSG, buffer())
        
        -- dissecting the version
        udp_tree:add(f.version, buffer:range(O_VERSION,2))
        
        -- dissecting the operation field
        local operation_val = buffer(O_OPERATION, 2):uint()
        udp_tree:add(f.operation, buffer:range(O_OPERATION, 2))
        
        -- dissecting length of options
        local options_length_val = buffer(O_LENGTH, 4):uint()
        udp_tree:add(f.length, buffer:range(O_LENGTH, 4))
        local options_node = udp_tree:add(f.options,buffer:range(O_OPTIONS,options_length_val))

        -- dissecting length of options        
        if (operation_val == ENUM_MSG_TYPE_STRVAL["Configuration mode"]) then
            -- Option 1 (and only): Config mode on/off
            local config_mode_val = buffer:range(O_OPTIONS, 1):uint()
            local config_mode_str = "Unknown"
            if config_mode_val == 0 then
                config_mode_str = "Action: Deactivate"
            elseif config_mode_val == 1 then
                config_mode_str = "Action: Activate"
            end
            -- Only one option, no need to add a subtree
            options_node:append_text(" ("..config_mode_str..")")
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Config Mode")
        elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Set IP address"]) then
            -- Option 1 (and only): IP address to set
            local config_ip_value = buffer:range(O_OPTIONS, 4):uint()
            local config_ip_str = get_ip_from_bytes(config_ip_value)
            -- Only one option, no need to add a subtree
            options_node:append_text(" (New IP address: "..config_ip_str..")")
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Set IP")
        elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Set Multicast MAC address"]) then
            -- Option 1 (and only): Multicast MAC address to set
            local config_mac_value = buffer:range(O_OPTIONS, 6):uint64()
            local config_mac_str = get_mac_from_bytes(config_mac_value)
            -- Only one option, no need to add a subtree
            options_node:append_text(" (New multicast MAC address: "..config_mac_str..")")
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Set Multicast MAC")
        elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Get probe info request"]) then
            -- Option 1 (and only): Probe info requested
            local probe_info_type_val = buffer:range(O_OPTIONS, 1):uint()
            local probe_info_type_str = "Unknown"
            if probe_info_type_val == 1 then
                probe_info_type_str = "Requested: HW info"
            elseif probe_info_type_val == 2 then
                probe_info_type_str = "Requested: Logging interface"
            end
            -- Only one option, no need to add a subtree
            options_node:append_text(" ("..probe_info_type_str..")")
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Probe Info Req")
        elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Get probe info response - Probe HW info"]) then
            -- Option 1: Vendor ID
            local info_vendor_id_val = buffer:range(O_OPTIONS + O_OPTIONS_INFO_VENDOR_ID,1):uint()
            local info_vendor_id_str = get_str_from_table(PLP_VENDOR_ID, info_vendor_id_val)
            options_info_vendor_id_node = options_node:add(f.options_probe_info_vendor_id, info_vendor_id_val)
            options_info_vendor_id_node:append_text(" ("..info_vendor_id_str..")")
            -- Option 2: Probe Type
            local info_probe_type_val = buffer:range(O_OPTIONS + O_OPTIONS_INFO_PROBE_TYPE,1):uint()
            local info_probe_type_str = get_str_from_table(PLP_PROBE_TYPE, info_probe_type_val)
            options_info_probe_type_node = options_node:add(f.options_probe_info_probe_type, info_probe_type_val)
            options_info_probe_type_node:append_text(" ("..info_probe_type_str..")")
            -- Option 3: Probe Serial Number
            local info_probe_serial_val = buffer:range(O_OPTIONS + O_OPTIONS_INFO_PROBE_SERIAL,4):uint()
            options_info_probe_serial_node = options_node:add(f.options_probe_info_probe_serial, info_probe_serial_val)
            -- Option 4: Eth Port Count
            local info_eth_count_val = buffer:range(O_OPTIONS + O_OPTIONS_INFO_ETH_PORT_COUNT,1):uint()
            options_eth_count_node = options_node:add(f.options_probe_info_eth_port_count, info_eth_count_val)
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Probe Info Resp - HW")
        elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Get probe info response - Probe Logging interface"]) then
            options_node:append_text(" ( << Interpretation pending >> )")
            -- Update the INFO column for this frame/packet
            pinfo.cols.info:set("UDP Probe Info Resp - Logging")
        else
            udp_tree:add(f.options,buffer:range(O_OPTIONS,options_length_val))
        end

        -- set the reserved offset
        O_RESERVED = O_OPTIONS + options_length_val
        -- dissect the reserved field
        udp_tree:add(f.reserved,buffer:range(O_RESERVED,4))

    end
    
    local udp_config_encap_table = DissectorTable.get("udp.port")
    udp_config_encap_table:add(UDP_CONFIG_PORT, P_UDP_CONFIG_MSG)
    
end

decode_and_append_option_two_bytes = function (buffer, options_node, decoded_string_base, O_OPTIONS, table_name)
    local option_val = buffer(O_OPTIONS, 2):uint()
    local option_str = get_str_from_table(table_name, option_val)
    decoded_string_result = decoded_string_base..option_str
    options_node:append_text(decoded_string_result)
    
    return decoded_string_result
end

get_ip_from_bytes = function (ip_bytes)
    a = bit32.band(bit32.rshift(ip_bytes, 24), 0xff)
    b = bit32.band(bit32.rshift(ip_bytes, 16), 0xff)
    c = bit32.band(bit32.rshift(ip_bytes, 8), 0xff)
    d = bit32.band(ip_bytes, 0xff)
    
    return (a.."."..b.."."..c.."."..d)
end

get_mac_from_bytes = function (mac_bytes)
    a = UInt64.band(UInt64.rshift(mac_bytes, 40), 0xff):tonumber()
    b = UInt64.band(UInt64.rshift(mac_bytes, 32), 0xff):tonumber()
    c = UInt64.band(UInt64.rshift(mac_bytes, 24), 0xff):tonumber()
    d = UInt64.band(UInt64.rshift(mac_bytes, 16), 0xff):tonumber()
    e = UInt64.band(UInt64.rshift(mac_bytes, 8), 0xff):tonumber()
    f = UInt64.band(mac_bytes, 0xff):tonumber()
    
    return (string.format("%02x",a)..":"..string.format("%02x",b)..":"..string.format("%02x",c)..":"..string.format("%02x",d)..":"..string.format("%02x",e)..":"..string.format("%02x",f))
end

get_str_from_table = function (table_name, value)
    str = table_name[value]
    if str == nil then
        str = "Unknown"
    end
    return str

end