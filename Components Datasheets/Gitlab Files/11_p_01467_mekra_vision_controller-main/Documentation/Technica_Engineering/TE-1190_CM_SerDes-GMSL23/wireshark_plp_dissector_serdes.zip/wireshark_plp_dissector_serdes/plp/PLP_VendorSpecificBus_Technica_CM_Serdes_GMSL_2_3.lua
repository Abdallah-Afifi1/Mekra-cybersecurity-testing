--------------------------------------------------------------------------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Guillem Prats
--
-------------------------------------------------------------------

-- Table with fields alignment
local al_f = {
	["vendor"] = 20
}

local c_TYPE_MESSAGE_FROM_INDEX = {
	[0] = "I2C_0",
	[1] = "I2C_1",
	[2] = "GPIO",
	[3] = "MIPI CSI-2 VC-0",
	[4] = "MIPI CSI-2 VC-1",
	[5] = "MIPI CSI-2 VC-2",
	[6] = "MIPI CSI-2 VC-3"
}
local c_TYPE_MESSAGE_LENGTH = 7

-- Type detector functions
function is_i2c_bus(bus_type_idx) 	return (bus_type_idx == 0 or bus_type_idx == 1) end
function is_gpio_bus(bus_type_idx) 	return (bus_type_idx == 2) end
function is_mipi_bus(bus_type_idx) 	return (bus_type_idx > 2 and bus_type_idx < c_TYPE_MESSAGE_LENGTH) end

do
	-- Create a new dissector
	VENDOR_STATUS_BUS_PROTO_CM_SERDES_GMSL2_3 = Proto("PLP_STATUS_BUS_VENDOR_TECHNICA_CM_SERDES_GMSL_2_3", "PLP Vendor Specific Bus Technica Engineering - CM Serdes GMSL 2/3")
	c_PROBE_TYPE_CM_SERDES_GMSL2_3 = 0x40

  -- Table for the protocol fields
	local plp_status_bus_fields = {
		bus_status = ProtoField.uint8("plp.status_bus.vendor.te.serdes.bus_status", _ljust("Bus Status Errors", al_f["vendor"]), base.HEX),
		i2c_no_ack_error = ProtoField.bool ("plp.status_bus.vendor.te.serdes.i2c_no_ack_error", _ljust("I2C No Ack Error", al_f["vendor"]), 8, {"Yes", "No"}, 0x01),
		mipi_crc_error = ProtoField.bool ("plp.status_bus.vendor.te.serdes.mipi_crc_error", _ljust("MIPI CRC Error", al_f["vendor"]), 8, {"Yes", "No"}, 0x01),
		mipi_ecc_1_error = ProtoField.bool ("plp.status_bus.vendor.te.serdes.mipi_ecc_1_error", _ljust("MIPI ECC 1-error", al_f["vendor"]), 8, {"Yes", "No"}, 0x02),
		mipi_ecc_2_error = ProtoField.bool ("plp.status_bus.vendor.te.serdes.mipi_ecc_2_error", _ljust("MIPI ECC 2-error", al_f["vendor"]), 8, {"Yes", "No"}, 0x04),
		reserved = ProtoField.uint8("plp.status_bus.vendor.te.serdes.reserved", _ljust("Reserved", al_f["vendor"]), base.HEX)
	}

	-- Register the ProtoFields
	VENDOR_STATUS_BUS_PROTO_CM_SERDES_GMSL2_3.fields = plp_status_bus_fields

	-- Create the protocol fields
	local plp_TE_table = DissectorTable.new("plp_vendor_technica_bus_cm_serdes", "plp_vendor_technica_bus")

	-- The dissector function
	function VENDOR_STATUS_BUS_PROTO_CM_SERDES_GMSL2_3.dissector (buffer, pinfo, tree)    
		-- offsets	
		O_BUS_STATUS = 0
		O_RESERVED = 1

		local remaining_bytes = buffer:len()
		local interface_type_idx = index_message%c_TYPE_MESSAGE_LENGTH
		local port_number = math.floor(index_message/c_TYPE_MESSAGE_LENGTH)
		local interface_type = c_TYPE_MESSAGE_FROM_INDEX[interface_type_idx]

		-- Adding fields to the tree
		local technica_tree = tree:add (VENDOR_STATUS_BUS_PROTO_CM_SERDES_GMSL2_3, buffer()):append_text(" (PORT " .. port_number .. " - " .. interface_type .. ")")

		-- Bus Status
		if remaining_bytes >= 1 then
			if is_i2c_bus(interface_type_idx) then
				local status_tree = technica_tree:add(plp_status_bus_fields.bus_status, buffer:range(O_BUS_STATUS, 1))
				-- error flags
				status_tree:add(plp_status_bus_fields.i2c_no_ack_error, buffer:range(O_BUS_STATUS, 1))
			elseif is_mipi_bus(interface_type_idx) then
				local status_tree = technica_tree:add(plp_status_bus_fields.bus_status, buffer:range(O_BUS_STATUS, 1))
				-- error flags
				status_tree:add(plp_status_bus_fields.mipi_crc_error, buffer:range(O_BUS_STATUS, 1))
				status_tree:add(plp_status_bus_fields.mipi_ecc_1_error, buffer:range(O_BUS_STATUS, 1))
				status_tree:add(plp_status_bus_fields.mipi_ecc_2_error, buffer:range(O_BUS_STATUS, 1))
			else
				technica_tree:add(plp_status_bus_fields.reserved, buffer:range(O_BUS_STATUS, 1))
			end
			remaining_bytes = remaining_bytes - 1
		end

		-- Reserved
		if remaining_bytes >= 1 then
			technica_tree:add(plp_status_bus_fields.reserved, buffer:range(O_RESERVED, 1))
			remaining_bytes = remaining_bytes - 1
		end
	end
	
	local plp_table_serdes = DissectorTable.get("plp.vendorspecificbus_serdes")
	plp_table_serdes:add(c_PROBE_TYPE_CM_SERDES_GMSL2_3, VENDOR_STATUS_BUS_PROTO_CM_SERDES_GMSL2_3)
end