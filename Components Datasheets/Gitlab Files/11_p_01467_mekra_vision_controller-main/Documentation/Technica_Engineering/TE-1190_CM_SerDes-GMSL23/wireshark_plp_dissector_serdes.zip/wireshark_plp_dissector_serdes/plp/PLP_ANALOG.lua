-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
--
-------------------------------------------------------------------


local analog_unit = {
	[0x0] = "V.",
	[0x1] = "A."
}

local analog_factor = {
	[0x0] = 0.1,
	[0x1] = 0.01,
	[0x2] = 0.001,
	[0x3] = 0.0001,
}

do
	-- Create a new dissector
	ANALOG_PROTO = Proto("PLP_ANALOG", "PLP ANALOG")
	const_analog_MsgType = 0x0020
	SAMPLE_SIZE = 2  -- in bytes
	local dissection_error = " !! dissection error: check length"
	
	-- Create the protocol fields
	local f = ANALOG_PROTO.fields
	
	f.sample = ProtoField.uint16 ("plp_analog.sample", "Sample", base.DEC)

	

	local plp_analog_table = DissectorTable.new("plp_analog", "plp-analog")

	-- The dissector function
	function ANALOG_PROTO.dissector (buffer, pinfo, tree)
		
		O_PROBE_FLAGS = 0
		O_PROBE_SAMPLES = 2
		local vd_flags_val = buffer:range(O_PROBE_FLAGS, 2):uint()
		
		local factor_val = get_factor(vd_flags_val)
		local unit_str = get_unit(vd_flags_val)	

	
		-- Adding fields to the tree
		local analog_tree = tree:add (ANALOG_PROTO, buffer())
		
		-- buff includes two extra bytes with the flags
		local samples_l = buffer:len() - 2
		local success, total_samples = get_number_of_samples(samples_l)
		if (not success) then
			-- show some warning
			analog_tree:append_text(dissection_error)
		end
		
		for current_sample = 1, total_samples, 1 do
			local current_sample_value = buffer:range(O_PROBE_SAMPLES + (current_sample - 1)*SAMPLE_SIZE, SAMPLE_SIZE):uint()
			current_sample_node = analog_tree:add(f.sample, buffer:range(O_PROBE_SAMPLES + (current_sample - 1)*SAMPLE_SIZE, SAMPLE_SIZE))
			if current_sample_value == 0 then
				local final_factor_value = 0
				formatted_str = string.format("Sample number %d: %d %s", current_sample, final_factor_value, unit_str)
			else
				local final_factor_value = current_sample_value*factor_val
				formatted_str = string.format("Sample number %d: %.4f %s", current_sample, final_factor_value, unit_str)				
			end
			current_sample_node:set_text(formatted_str)
		end
		
		
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_analog_MsgType, ANALOG_PROTO)
end

get_factor = function (probe_flags)
	
	PROBE_FLAGS_MASK_FACTOR = 0x3
	PROBE_FLAGS_SHIFT_FACTOR = 7
	
	factor_enum = bit32.band(bit32.rshift(probe_flags, PROBE_FLAGS_SHIFT_FACTOR), PROBE_FLAGS_MASK_FACTOR)
	return analog_factor[factor_enum]

end

get_unit = function (probe_flags)
	PROBE_FLAGS_MASK_UNIT = 0x3
	PROBE_FLAGS_SHIFT_UNIT = 2
	
	unit_enum = bit32.band(bit32.rshift(probe_flags, PROBE_FLAGS_SHIFT_UNIT), PROBE_FLAGS_MASK_UNIT)
	return analog_unit[unit_enum]

end

-----------------
-- Calculate the number of samples in the frame
--
-- @param total_length of the ANALOG layer
--
-- @return success: if SAMPLE_SIZE did fit into the total_length completely
-- @return quotient: number of samples
get_number_of_samples = function (total_length)
	success = false
	quotient = total_length / SAMPLE_SIZE
	remainder = total_length % SAMPLE_SIZE
	if (remainder == 0) then
		success = true
	end
	return success, quotient	
end