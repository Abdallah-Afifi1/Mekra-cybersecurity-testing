-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------

---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["plp_lin"] = 10
}


do
	-- Create a new dissector
	LIN_PROTO = Proto("PLP_LIN", "PLP LIN")
	const_lin_MsgType = 0x0004
	
	-- Create the protocol fields
	local f = LIN_PROTO.fields
	
	f.identifier = ProtoField.uint8 ("plp_lin.identifier", _ljust("Identifier", al_f["plp_lin"]), base.HEX)
	f.length = ProtoField.uint8 ("plp_lin.length", _ljust("Length", al_f["plp_lin"]), base.DEC)
	f.payload = ProtoField.bytes ("plp_lin.payload", _ljust("Payload", al_f["plp_lin"]))
	f.checksum = ProtoField.uint8 ("plp_lin.checksum", _ljust("Checksum", al_f["plp_lin"]), base.HEX)
	

	local plp_lin_table = DissectorTable.new("plp_lin", "plp_lin")

	-- The dissector function
	function LIN_PROTO.dissector (buffer, pinfo, tree)
		-- Adding fields to the tree
		local lin_tree = tree:add (LIN_PROTO, buffer())
	
		local identifier_raw = buffer(0, 1)

		lin_tree:add(f.identifier, buffer:range(0,1))

		local length_lin_val = buffer(1, 1):uint()
		lin_tree:add(f.length, buffer:range(1,1), length_lin_val)
		
        if length_lin_val > 0 then
            lin_tree:add(f.payload, buffer:range(2,length_lin_val))
		
            lin_tree:add(f.checksum, buffer:range(2 + length_lin_val, 1))
        end
		
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_lin_MsgType, LIN_PROTO)
end