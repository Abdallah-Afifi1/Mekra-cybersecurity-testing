-- @change me:
dissector_proto_version = "[Dissector v9.0.0]"

local PLP_UE_ID = {
    [0x0002] = "Logger Ready",    
    [0x0004] = "Logger Shut Down",
    [0x0100] = "Range ADCAM Low",
    [0x01FF] = "Range ADCAM Low",
    [0x0101] = "ADCAM Low Bus Data Vali-dation Failed",
    [0x0102] = "ADACM Low Raw Data Vali-dation Failed",
    [0x0103] = "ADCAM Low ECU Error / HW Reset",
    [0x0104] = "ADCAM Low Sensors Blind",
    [0x0200] = "Range ADCAM MID",
    [0x02FF] = "Range ADCAM MID",
    [0x0300] = "Range ADCAM High / hPad",
    [0x03FF] = "Range ADCAM High / hPad",
    [0x0400] = "Range UCAP",
    [0x04FF] = "Range UCAP",
    [0x0500] = "Range USS",
    [0x05FF] = "Range USS",
    [0x0600] = "Range SRR",
    [0x06FF] = "Range SRR",
    [0x0700] = "Range MRR",
    [0x07FF] = "Range MRR",
    [0x0800] = "Range FRR",
    [0x08FF] = "Range FRR",
    [0x0900] = "Range LIDAR",
    [0x09FF] = "Range LIDAR"

}

local PLP_VENDOR_ID = {
    [0x04] = "AeD",
    [0x08] = "Conti",
    [0x0C] = "Technica",
    [0x10] = "ViGEM",
    [0x14] = "X2E",
    [0x20] = "Magna",
    [0x22] = "Valeo",
    [0x24] = "Aptiv"
}

local PLP_PROBE_ID = {
	[48] = "LIN Combo 0 - 10.104.3.48",
	[49] = "LIN Combo 1 - 10.104.3.49",
	[50] = "LIN Combo 2 - 10.104.3.50",
	[51] = "LIN Combo 3 - 10.104.3.51",
	[52] = "LIN Combo 4 - 10.104.3.52",
	[53] = "LIN Combo 5 - 10.104.3.53",
	[54] = "LIN Combo 6 - 10.104.3.54",
	[55] = "LIN Combo 7 - 10.104.3.55",
	[56] = "LIN Combo 8 - 10.104.3.56",
	[57] = "LIN Combo 9 - 10.104.3.57",
	[58] = "LIN Combo 10 - 10.104.3.58",
	[59] = "LIN Combo 11 - 10.104.3.59",
	[60] = "LIN Combo 12 - 10.104.3.60",
	[61] = "LIN Combo 13 - 10.104.3.61",
	[62] = "LIN Combo 14 - 10.104.3.62",
	[63] = "LIN Combo 15 - 10.104.3.63",
	[64] = "CAN Combo 0 - 10.104.3.64",
	[65] = "CAN Combo 1 - 10.104.3.65",
	[66] = "CAN Combo 2 - 10.104.3.66",
	[67] = "CAN Combo 3 - 10.104.3.67",
	[68] = "CAN Combo 4 - 10.104.3.68",
	[69] = "CAN Combo 5 - 10.104.3.69",
	[70] = "CAN Combo 6 - 10.104.3.70",
	[71] = "CAN Combo 7 - 10.104.3.71",
	[72] = "CAN Combo 8 - 10.104.3.72",
	[73] = "CAN Combo 9 - 10.104.3.73",
	[74] = "CAN Combo 10 - 10.104.3.74",
	[75] = "CAN Combo 11 - 10.104.3.75",
	[76] = "CAN Combo 12 - 10.104.3.76",
	[77] = "CAN Combo 13 - 10.104.3.77",
	[78] = "CAN Combo 14 - 10.104.3.78",
	[79] = "CAN Combo 15 - 10.104.3.79",
	[96] = "100 High 0 - 10.104.3.96",
	[97] = "100 High 1 - 10.104.3.97",
	[98] = "100 High 2 - 10.104.3.98",
	[99] = "100 High 3 - 10.104.3.99",
	[100] = "100 High 4 - 10.104.3.100",
	[101] = "100 High 5 - 10.104.3.101",
	[102] = "100 High 6 - 10.104.3.102",
	[103] = "100 High 7 - 10.104.3.103",
	[104] = "100 High 8 - 10.104.3.104",
	[105] = "100 High 9 - 10.104.3.105",
	[106] = "100 High 10 - 10.104.3.106",
	[107] = "100 High 11 - 10.104.3.107",
	[108] = "100 High 12 - 10.104.3.108",
	[109] = "100 High 13 - 10.104.3.109",
	[110] = "100 High 14 - 10.104.3.110",
	[111] = "100 High 15 - 10.104.3.111",
	[128] = "Eth Combo 0 - 10.104.3.128",
	[129] = "Eth Combo 1 - 10.104.3.129",
	[130] = "Eth Combo 2 - 10.104.3.130",
	[131] = "Eth Combo 3 - 10.104.3.131",
	[132] = "Eth Combo 4 - 10.104.3.132",
	[133] = "Eth Combo 5 - 10.104.3.133",
	[134] = "Eth Combo 6 - 10.104.3.134",
	[135] = "Eth Combo 7 - 10.104.3.135",
	[136] = "Eth Combo 8 - 10.104.3.136",
	[137] = "Eth Combo 9 - 10.104.3.137",
	[138] = "Eth Combo 10 - 10.104.3.138",
	[139] = "Eth Combo 11 - 10.104.3.139",
	[140] = "Eth Combo 12 - 10.104.3.140",
	[141] = "Eth Combo 13 - 10.104.3.141",
	[142] = "Eth Combo 14 - 10.104.3.142",
	[143] = "Eth Combo 15 - 10.104.3.143",
	[144] = "1000 High 0 - 10.104.3.144",
	[145] = "1000 High 1 - 10.104.3.145",
	[146] = "1000 High 2 - 10.104.3.146",
	[147] = "1000 High 3 - 10.104.3.147",
	[148] = "1000 High 4 - 10.104.3.148",
	[149] = "1000 High 5 - 10.104.3.149",
	[150] = "1000 High 6 - 10.104.3.150",
	[151] = "1000 High 7 - 10.104.3.151",
	[152] = "1000 High 8 - 10.104.3.152",
	[153] = "1000 High 9 - 10.104.3.153",
	[154] = "1000 High 10 - 10.104.3.154",
	[155] = "1000 High 11 - 10.104.3.155",
	[156] = "1000 High 12 - 10.104.3.156",
	[157] = "1000 High 13 - 10.104.3.157",
	[158] = "1000 High 14 - 10.104.3.158",
	[159] = "1000 High 15 - 10.104.3.159",
	
	[192] = "SerDes Adpater (allgemein) - 10.104.3.192",
	[193] = "ADCAM low - 10.104.3.193",
	[194] = "ADCAM mid - 10.104.3.194",
	[195] = "UCAP - 10.104.3.195",
	[196] = "SerDes xPAD - 10.104.3.196",
	[197] = "SerDes xPAD - 10.104.3.197",
	[198] = "SerDes xPAD from UCAP - 10.104.3.198",
	[199] = "SerDes xPAD from ADCAM - 10.104.3.199",
	
	[200] = "SerDes LIDAR vorne - 10.104.3.200",
	[201] = "SerDes LIDAR vorne links - 10.104.3.201",
	[202] = "SerDes LIDAR vorne rechts - 10.104.3.202",
	[203] = "SerDes LIDAR hinten links - 10.104.3.203",
	[204] = "SerDes LIDAR hinten rechts - 10.104.3.204",
	[205] = "SerDes ARCAM - 110.104.3.205",
	
	[177] = "MRR-MTA-B - 10.104.3.177",
	[178] = "FRR-MTA-B - 10.104.3.178",
	
    [179] = "UCAP TIC (TestInterface Card)- V3H - 10.104.3.179",
    [180] = "UCAP TIC (TestInterface Card)- M3N - 10.104.3.179",
	[181] = "USS MTA  - 10.104.3.181",
	[16] = "Logger 1 - 10.104.3.16",
	[17] = "Logger 2 - 10.104.3.17",
	[18] = "Logger 3 - 10.104.3.18"			
}

local PLP_PROBE_TYPE = {
	[0x02] = "CM LIN Combo",
	[0x04] = "CM CAN Combo",
	[0x06] = "CM 100 High",
	[0x08] = "CM Eth Combo",
	[0x0A] = "CM 1000 High",
	[0x10] = "SensorSpezifisch",
	[0x20] = "Logger",
    [0x40] = "CM Serdes GMSL2/3"
}

---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end

--------------------------------
-- Table with fields alignment
local al_f = {
  ["udp_msg"] = 34,
  ["udp_msg_options"] = 32
}

local ENUM_OPERATION = {
	[0x0000] = "Discovery request",
	[0x0001] = "Discovery response",
	[0x0005] = "User Events",
}

----------------------------------------
-- a function to convert tables of enumerated types to value-string tables
-- i.e., from { "name" = number } to { number = "name" }
local function makeValString(enumTable)
    local t = {}
    for name,num in pairs(enumTable) do
        t[num] = name
    end
    return t
end

local ENUM_MSG_TYPE_STRVAL = makeValString(ENUM_OPERATION)

do
	-- description of PLP UDP Operation message
	local P_UDP_OP_MSG = Proto("PLP_UDP", "(PLP) UDP")

	-- Create the protocol fields
	local f = P_UDP_OP_MSG.fields
	
	f.version = ProtoField.uint16("plp_udp.version", 
									_ljust("version", al_f["udp_msg"]), 
									base.HEX)    
    f.operation = ProtoField.uint16("plp_udp.operation", 
                                _ljust("Operation", al_f["udp_msg"]), 
                                base.HEX, 
                                ENUM_OPERATION)
	f.length = ProtoField.uint32("plp_udp.length", 
								_ljust('Length of "Options" field in bytes',
								al_f["udp_msg"]), 
								base.DEC)                                
    f.options = ProtoField.bytes("plp_udp.options", 
								_ljust("Options",
								al_f["udp_msg"]), 
								base.NONE) 
    f.options_userevent_probe_id = ProtoField.bytes("plp_udp.options.probe_id", 
                                    _ljust("Probe ID", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)
    f.options_userevent_ue_id = ProtoField.bytes("plp_udp.options.ue_id", 
                                    _ljust("User Event ID", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)
    f.options_disc_resp_src_mac = ProtoField.bytes("plp_udp.options.src_mac", 
                                    _ljust("Source MAC address", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)
    f.options_disc_resp_src_ip = ProtoField.bytes("plp_udp.options.src_ip", 
                                    _ljust("Source IP address", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)  
    f.options_disc_resp_mc_mac = ProtoField.bytes("plp_udp.options.mc_mac", 
                                    _ljust("Multicast MAC address", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)  
    f.options_disc_resp_dst_ip = ProtoField.bytes("plp_udp.options.dst_ip", 
                                    _ljust("Destination IP address", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)  
    f.options_disc_resp_probe_id = ProtoField.bytes("plp_udp.options.probe_id", 
                                    _ljust("Probe ID", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)  
    f.options_disc_resp_probe_fw = ProtoField.bytes("plp_udp.options.probe_fw", 
                                    _ljust("Probe FW version", 
                                    al_f["udp_msg_options"]), 
                                    base.NONE)
    f.operation = ProtoField.uint16("plp_udp.operation", 
                                _ljust("Operation", al_f["udp_msg"]), 
                                base.HEX, 
                                ENUM_OPERATION)
    f.reserved = ProtoField.bytes("plp_udp.reserved", 
								_ljust("Reserved",
								al_f["udp_msg"]), 
								base.NONE)
                                
                                	-- Dissector function
	function P_UDP_OP_MSG.dissector(buffer, pinfo, tree)
        -- set the protocol column to show our protocol name
        pinfo.cols.protocol:set("PLP "..dissector_proto_version)
        
        -- set the INFO column for this frame/packet
        pinfo.cols.info:set("UDP tbd")

        -- some offsets	
		O_VERSION = 0
        O_OPERATION = 2
        O_LENGTH = 4
        O_OPTIONS = 8

        -- -- Offsets for User Events
        O_OPTIONS_UE_PROBE_ID = 0
        O_OPTIONS_UE_UE_ID = 2
        -- -- Offsets for Discovery Response messages
        O_OPTIONS_DISC_RESP_SRC_MAC = 0
        O_OPTIONS_DISC_RESP_SRC_IP = 6
        O_OPTIONS_DISC_RESP_MC_MAC = 10
        O_OPTIONS_DISC_RESP_DST_IP = 16
        O_OPTIONS_DISC_RESP_PROBE_ID = 20
        O_OPTIONS_DISC_RESP_PROBE_FW = 24
		        
        -- Adding fields to the tree
		local udp_tree = tree:add (P_UDP_OP_MSG, buffer())
        
        -- dissecting the version
        udp_tree:add(f.version, buffer:range(O_VERSION,2))
        
        -- dissecting the operation field
        local operation_val = buffer(O_OPERATION, 2):uint()
        udp_tree:add(f.operation, buffer:range(O_OPERATION, 2))
        
        -- dissecting length of options
        local options_length_val = buffer(O_LENGTH, 4):uint()
        udp_tree:add(f.length, buffer:range(O_LENGTH, 4))
        local options_node = udp_tree:add(f.options,buffer:range(O_OPTIONS,options_length_val))
        
        if (operation_val == ENUM_MSG_TYPE_STRVAL["User Events"]) then
            -- Option 1: Probe ID
            local ue_probe_id_val = buffer:range(O_OPTIONS + O_OPTIONS_UE_PROBE_ID,2):uint()
            local ue_probe_id_str = get_str_from_table(PLP_PROBE_ID, ue_probe_id_val)
            options_ue_probe_id_node = options_node:add(f.options_userevent_probe_id, buffer:range(O_OPTIONS + O_OPTIONS_UE_PROBE_ID,2))
            options_ue_probe_id_node:append_text(" ("..ue_probe_id_str..")")
            -- Option 2: UE ID
            local ue_id_val = buffer:range(O_OPTIONS + O_OPTIONS_UE_UE_ID,2):uint()
            local ue_id_str = get_str_from_table(PLP_UE_ID, ue_id_val)
            options_ue_id_node = options_node:add(f.options_userevent_ue_id, buffer:range(O_OPTIONS + O_OPTIONS_UE_UE_ID,2))
            options_ue_id_node:append_text(" ("..ue_id_str..")")
            -- Update info
            pinfo.cols.info:set("UDP User Event - "..ue_id_str)
		elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Discovery request"]) then
            -- No options
            pinfo.cols.info:set("UDP Discovery Req")
		elseif (operation_val == ENUM_MSG_TYPE_STRVAL["Discovery response"]) then
            -- Option 1: Source MAC address
			local disc_src_mac_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_SRC_MAC,6):uint64()
            local disc_src_mac_str = get_mac_from_bytes(disc_src_mac_val)            
            
			options_disc_src_mac_node = options_node:add(f.options_disc_resp_src_mac, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_SRC_MAC,6))
			
			options_disc_src_mac_node:append_text(" ("..disc_src_mac_str..")")

            -- Option 2: Source IP address
            local disc_src_ip_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_SRC_IP,4):uint()
            local disc_src_ip_str = get_ip_from_bytes(disc_src_ip_val)
            options_disc_src_ip_node = options_node:add(f.options_disc_resp_src_ip, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_SRC_IP,4))
            options_disc_src_ip_node:append_text(" ("..disc_src_ip_str..")")
			
            -- Option 3: Multicast MAC address
            local disc_mc_mac_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_MC_MAC,6):uint64()
            local disc_mc_mac_str = get_mac_from_bytes(disc_mc_mac_val)
            options_disc_mc_mac_node = options_node:add(f.options_disc_resp_mc_mac, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_MC_MAC,6))
            options_disc_mc_mac_node:append_text(" ("..disc_mc_mac_str..")")
			
			
            -- Option 4: Destination IP address
            local disc_dst_ip_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_DST_IP,4):uint()
            local disc_dst_ip_str = get_ip_from_bytes(disc_dst_ip_val)
            options_disc_dst_ip_node = options_node:add(f.options_disc_resp_dst_ip, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_DST_IP,4))
            options_disc_dst_ip_node:append_text(" ("..disc_dst_ip_str..")")
			
            -- Option 5: Probe ID
            local disc_probe_id_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_ID,4):uint()
            local disc_probe_id_str = get_str_from_table(PLP_PROBE_ID, disc_probe_id_val)
            options_disc_probe_id_node = options_node:add(f.options_disc_resp_probe_id, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_ID,4))
            options_disc_probe_id_node:append_text(" ("..disc_probe_id_str..")")
			
            -- Option 6: Probe Firmware version
            local disc_probe_fw_val = buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_FW,4):uint()
            sw1 =  buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_FW + 1,1):uint()
            sw2 =  buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_FW + 2,1):uint()
            sw3 =  buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_FW + 3,1):uint()
            local disc_probe_fw_str = "v"..sw1.."."..sw2.."."..sw3
            options_disc_probe_fw_node = options_node:add(f.options_disc_resp_probe_fw, buffer:range(O_OPTIONS + O_OPTIONS_DISC_RESP_PROBE_FW,4))
            options_disc_probe_fw_node:append_text(" ("..disc_probe_fw_str..")")
            pinfo.cols.info:set("UDP Discovery Resp")
        else
            -- Nothing to do
        end

        -- set the reserved offset
        O_RESERVED = O_OPTIONS + options_length_val
        -- dissect the reserved field
        udp_tree:add(f.reserved,buffer:range(O_RESERVED,4))

    end
	
	local udp_encap_table = DissectorTable.get("udp.port")
	udp_encap_table:add(9999, P_UDP_OP_MSG)
	
end

decode_and_append_option_two_bytes = function (buffer, options_node, decoded_string_base, O_OPTIONS, table_name)
    local option_val = buffer(O_OPTIONS, 2):uint()
    local option_str = get_str_from_table(table_name, option_val)
    decoded_string_result = decoded_string_base..option_str
    options_node:append_text(decoded_string_result)
    
    return decoded_string_result
end

get_ip_from_bytes = function (ip_bytes)
    a = bit32.band(bit32.rshift(ip_bytes, 24), 0xff)
    b = bit32.band(bit32.rshift(ip_bytes, 16), 0xff)
    c = bit32.band(bit32.rshift(ip_bytes, 8), 0xff)
    d = bit32.band(ip_bytes, 0xff)
    
    return (a.."."..b.."."..c.."."..d)
end

get_mac_from_bytes = function (mac_bytes)
    a = UInt64.band(UInt64.rshift(mac_bytes, 40), 0xff):tonumber()
    b = UInt64.band(UInt64.rshift(mac_bytes, 32), 0xff):tonumber()
    c = UInt64.band(UInt64.rshift(mac_bytes, 24), 0xff):tonumber()
    d = UInt64.band(UInt64.rshift(mac_bytes, 16), 0xff):tonumber()
    e = UInt64.band(UInt64.rshift(mac_bytes, 8), 0xff):tonumber()
    f = UInt64.band(mac_bytes, 0xff):tonumber()
    
    return (string.format("%02x",a)..":"..string.format("%02x",b)..":"..string.format("%02x",c)..":"..string.format("%02x",d)..":"..string.format("%02x",e)..":"..string.format("%02x",f))
end

get_str_from_table = function (table_name, value)
	str = table_name[value]
    if str == nil then
        str = "Unknown"
    end
    return str

end