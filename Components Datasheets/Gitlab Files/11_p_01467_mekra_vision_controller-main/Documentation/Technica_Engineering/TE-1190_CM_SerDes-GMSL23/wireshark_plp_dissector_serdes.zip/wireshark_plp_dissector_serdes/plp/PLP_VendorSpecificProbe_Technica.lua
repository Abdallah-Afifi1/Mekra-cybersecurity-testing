--------------------------------------------------------------------------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
--
-------------------------------------------------------------------

---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end

local BUFFER_OVERFLOW_ENUM = {
	[0x00] = "No buffer overflow",
	[0x01] = "Buffer overflow"
}
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["vendor"] = 20
}

local c_PROBE_TYPE_CM_SERDES_GMSL2_3 = 0x40
local table_plp_probe_type_specific_status = DissectorTable.new("plp.vendorspecificprobe_serdes", "plp.config.vendorspecificprobe_serdes")

do
	-- Create a new dissector
	VENDOR_STATUS_PROBE_PROTO = Proto("PLP_STATUS_PROBE_VENDOR_TECHNICA", "PLP Vendor Specific Probe Technica Engineering")
	const_vendor_id = 0x0C
	
	-- Create the protocol fields
	local f = VENDOR_STATUS_PROBE_PROTO.fields
    f.reserved_1 = ProtoField.uint8 ("plp.status_probe.vendor.te.reserved1", _ljust("Reserved", al_f["vendor"]), base.HEX)
    -- Software version defined as uint8.uint8.uint8
    f.swversion = ProtoField.string ("plp.status_probe.vendor.te.swversion", _ljust("Software Version", al_f["vendor"]))
    
    -- Hardware version defined as uint8.uint8
    f.hwversion = ProtoField.string ("plp.status_probe.vendor.te.hwversion", _ljust("Hardware Version", al_f["vendor"]))
    
    -- Buffer fill level
    f.bufferfilllevel = ProtoField.uint32 ("plp.status_probe.vendor.te.bufferfilllevel", _ljust("Buffer Fill Level", al_f["vendor"]), base.DEC)
    
    -- Buffer overflow
    f.bufferoverflow = ProtoField.uint8 ("plp.status_probe.vendor.te.bufferoverflow", _ljust("Buffer Overflow", al_f["vendor"]), base.HEX, BUFFER_OVERFLOW_ENUM)
	
    -- Buffer size
    f.buffersize = ProtoField.uint32("plp.status_probe.vendor.te.buffersize", _ljust("Buffer Size", al_f["vendor"]), base.DEC)
    
    -- Lifecylce
    f.lifecycle = ProtoField.uint64("plp.status_probe.vendor.te.lifecycle", _ljust("Lifecyle", al_f["vendor"]), base.DEC)
    
    -- Voltage
    f.voltage = ProtoField.string ("plp.status_probe.vendor.te.voltage", _ljust("Voltage", al_f["vendor"]))

    -- Temperature
    f.temperature = ProtoField.uint8 ("plp.status_probe.vendor.te.temperature", _ljust("Temperature", al_f["vendor"]), base.DEC)

    -- Reserved 2
    --f.reserved_2 = ProtoField.uint8 ("plp.status_probe.vendor.tereserved2", _ljust("Reserved", al_f["vendor"]), base.HEX)
        
	local plp_TE_table = DissectorTable.new("plp_vendor_technica_probe", "plp_vendor_technica_probe")

	-- The dissector function
	function VENDOR_STATUS_PROBE_PROTO.dissector (buffer, pinfo, tree)
        -- some offsets	
        O_RESERVED_1 = 0
        O_SW_VERSION_COMPONENT_1 = 1
        O_SW_VERSION_COMPONENT_2 = 2
        O_SW_VERSION_COMPONENT_3 = 3
        O_HW_VERSION_COMPONENT_1 = 4
        O_HW_VERSION_COMPONENT_2 = 5
        O_BUFFER_FILL_LEVEL = 6
        O_BUFFER_OVERFLOW = 7
        O_BUFFER_SIZE = 8
        O_LIFECYCLE = 12
        O_VOLT_INTEGER = 20
        O_VOLT_FRACTIONAL = 21
        O_TEMPERATURE = 22
        O_RESERVED_2 = 23
    
		-- Adding fields to the tree
		local technica_tree = tree:add (VENDOR_STATUS_PROBE_PROTO, buffer())	
        
    -- Reserved field
    technica_tree:add(f.reserved_1, buffer:range(O_RESERVED_1,1))
    
    -- Software version: sw1.sw2.sw3
    sw1 =  buffer:range(O_SW_VERSION_COMPONENT_1,1):uint()
    sw2 =  buffer:range(O_SW_VERSION_COMPONENT_2,1):uint()
    sw3 =  buffer:range(O_SW_VERSION_COMPONENT_3,1):uint()
    str_sw_version = "v"..sw1.."."..sw2.."."..sw3
    sw_node = technica_tree:add(f.swversion, buffer:range(O_SW_VERSION_COMPONENT_1, 3), str_sw_version)
    
    -- Hardware version: hw1.hw2
    hw1 = buffer:range(O_HW_VERSION_COMPONENT_1,1):uint()
    hw2 = buffer:range(O_HW_VERSION_COMPONENT_2,1):uint()
    str_hw_version = "HW v"..hw1.."."..hw2.."."
    hw_node = technica_tree:add(f.hwversion, buffer:range(O_HW_VERSION_COMPONENT_1, 2), str_hw_version)
    
    -- Buffer fill level
    buffer_fill_node = technica_tree:add(f.bufferfilllevel, buffer:range(O_BUFFER_FILL_LEVEL, 1))
    buffer_fill_node:append_text("%")
    
    -- Buffer overflow
    technica_tree:add(f.bufferoverflow, buffer:range(O_BUFFER_OVERFLOW, 1))
    
    -- Buffer Size
    technica_tree:add(f.buffersize, buffer:range(O_BUFFER_SIZE, 4))
    
    -- Lifecycle
    lifecyle_node = technica_tree:add(f.lifecycle, buffer:range(O_LIFECYCLE, 8))
    lifecyle_node:append_text(" ns.")
    
    -- Voltage
    volt_int = buffer:range(O_VOLT_INTEGER, 1):uint()
    volt_frac = buffer:range(O_VOLT_FRACTIONAL, 1):uint()
    str_voltage = volt_int..","..volt_frac.."V."
    technica_tree:add(f.voltage, buffer:range(O_VOLT_INTEGER, 2), str_voltage)

    -- Temperature
    technica_tree:add(f.temperature, buffer:range(O_TEMPERATURE, 1)):append_text(" ºC")
    
    -- Probe-type specific part of the dissector
    if probe_type_val == c_PROBE_TYPE_CM_SERDES_GMSL2_3 then
      local newtvb = buffer(O_TEMPERATURE+1,-1):tvb()
      table_plp_probe_type_specific_status:try(probe_type_val, newtvb, pinfo, technica_tree)  
    else
      -- Default dissector
    
      -- Reserved
      --technica_tree:add(f.reserved_2, buffer:range(O_RESERVED_2, 1))
    end
	end
	
	plp_table = DissectorTable.get("plp.vendorspecificprobe")
	plp_table:add(const_vendor_id, VENDOR_STATUS_PROBE_PROTO)
end