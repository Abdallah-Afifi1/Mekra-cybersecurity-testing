-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


do
	-- Create a new dissector
	RS232_RAW_PROTO = Proto("PLP_RS232_RAW", "PLP RS232-RAW")
	const_rs232_raw_MsgType = 0x0011
	
	-- Create the protocol fields
	local f = RS232_RAW_PROTO.fields
	
	f.payload = ProtoField.bytes ("plp_rs232_raw.payload", "Payload", base.NONE)

	

	local plp_rs232_raw_table = DissectorTable.new("plp_rs232_raw", "plp_rs232_raw")

	-- The dissector function
	function RS232_RAW_PROTO.dissector (buffer, pinfo, tree)
		


		-- Adding fields to the tree
		local rs232_raw_tree = tree:add (RS232_RAW_PROTO, buffer())
		
		rs232_raw_tree:add(f.payload, buffer:range(0, buffer:len()))
		
		
	end
	
	plp_table = DissectorTable.get("plp")
	plp_table:add(const_rs232_raw_MsgType, RS232_RAW_PROTO)
end