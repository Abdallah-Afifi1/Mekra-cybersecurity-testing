-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["vendor"] = 24,

}

do
	-- Create a new dissector
	VENDOR_STATUS_CONFIG_PROTO = Proto("PLP_STATUS_CONFIG_VENDOR_TECHNICA", "PLP Serialized CM Configuration Technica Engineering")
	const_vendor_id = 0x0C
	
	-- Create the protocol fields
	local f = VENDOR_STATUS_CONFIG_PROTO.fields
	
	f.version = ProtoField.uint8("plp_status_config.vendor.te.version", _ljust("Version", al_f["vendor"]))
	
	f.reserved = ProtoField.uint8("plp_status_config.vendor.te.reserved", _ljust("Reserved", al_f["vendor"]), base.HEX)
	
	f.message_id = ProtoField.uint16("plp_status_config.vendor.te.message_id", _ljust("Message ID", al_f["vendor"]))
	
	
	f.total_length = ProtoField.uint32("plp_status_config.vendor.te.total_length", _ljust("Total Length", al_f["vendor"]))
	
	f.total_number_of_segments = ProtoField.uint16("plp_status_config.vendor.te.total_number_of_segments", _ljust("Total Number of Segments", al_f["vendor"]))
	
	f.segment_number = ProtoField.uint8("plp_status_config.vendor.te.segment_number", _ljust("Segment Number", al_f["vendor"]))
	

	
	f.segment_length = ProtoField.uint16("plp_status_config.vendor.te.segment_length", _ljust("Segment Length", al_f["vendor"]))
	
	
    f.serialized_data = ProtoField.bytes ("plp_status_config.vendor.te.data", _ljust("VendorSpecificConfig", al_f["vendor"]))

	
	local plp_TE_table = DissectorTable.new("plp_vendor_technica", "plp_vendor_technica")

	-- The dissector function
	function VENDOR_STATUS_CONFIG_PROTO.dissector (buffer, pinfo, tree)
        -- some offsets	
		O_VERSION = 0
		O_RESERVERD = 1
		O_MESSAGE_ID = 2
		O_TOTAL_LENGTH = 4
		O_TOTAL_NUMBER_OF_SEGMENTS = 8
		O_SEGMENT_NUMBER = 10
		O_LENGTH_OF_SEGMENT = 12
        O_SERIALIZED_DATA = 14
    
		-- Adding fields to the tree
		local technica_tree = tree:add (VENDOR_STATUS_CONFIG_PROTO, buffer())


		-- version
		technica_tree:add(f.version, buffer:range(O_VERSION, 1))
		
		-- reserved
		technica_tree:add(f.reserved, buffer:range(O_RESERVERD, 1))
		
		-- unique counter
		technica_tree:add(f.message_id, buffer:range(O_MESSAGE_ID, 2))
		
		-- length options
		technica_tree:add(f.total_length, buffer:range(O_TOTAL_LENGTH, 4))
		
		
		-- total number of segments
		technica_tree:add(f.total_number_of_segments, buffer:range(O_TOTAL_NUMBER_OF_SEGMENTS, 2))
		
		-- segment number
		technica_tree:add(f.segment_number, buffer:range(O_SEGMENT_NUMBER, 2))
		
		-- length of segment
		technica_tree:add(f.segment_length, buffer:range(O_LENGTH_OF_SEGMENT, 2))
		
		-- serialized data
        technica_tree:add(f.serialized_data, buffer:range(O_SERIALIZED_DATA, buffer:len() - O_SERIALIZED_DATA ))


	end
	
	plp_table = DissectorTable.get("plp.vendorspecificconfig")
	plp_table:add(const_vendor_id, VENDOR_STATUS_CONFIG_PROTO)
end