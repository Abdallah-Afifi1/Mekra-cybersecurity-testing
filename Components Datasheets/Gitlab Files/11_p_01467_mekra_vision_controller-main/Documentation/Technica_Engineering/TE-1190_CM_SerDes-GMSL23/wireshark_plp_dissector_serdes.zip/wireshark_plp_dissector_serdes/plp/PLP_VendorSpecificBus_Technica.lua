-------------------------------------------------------------------
-- PLP Lua dissector
--
-- This dissector has been rewritten based on previous versions.
--
-- @author: Raul Khalil
-------------------------------------------------------------------


---------------------------------------------------------------
-- Return the string left justified in a string of length width
---------------------------------------------------------------

_ljust = function(str, final_len)
	CHARACTER_TO_FILL = " "
	str_len = string.len(str)
	
	if str_len >= final_len then
		return str
	end
	len_to_fill = final_len - str_len
	return str..string.rep(CHARACTER_TO_FILL,len_to_fill)
	
end

local LINK_QUALITY_ENUM = {
    [0x00] = "Unacceptable or Down (0/5)",
    [0x01] = "Poor (1/5)",
    [0x02] = "Marginal (2/5)",
    [0x03] = "Good (3/5)",
    [0x04] = "Very good (4/5)",
    [0x05] = "Excellent (5/5)"
}


local LINK_STATUS_ENUM = {
	[0x00] = "LinkDown",
	[0x01] = "LinkUp"
}

local LINKUP_TIME_ENUM = {
	[0] = " (No linkUp detected / timeout did not happened yet)",
	[65535] = " (No linkUp detected / timeout happened already)"
}
	
--------------------------------
-- Table with fields alignment
local al_f = {
  ["vendor"] = 18,
}

local c_PROBE_TYPE_CM_SERDES_GMSL2_3 = 0x40
local table_plp_bus_type_specific_status = DissectorTable.new("plp.vendorspecificbus_serdes", "plp.config.vendorspecificbus_serdes")

do
	-- Create a new dissector
	VENDOR_STATUS_BUS_PROTO = Proto("PLP_STATUS_BUS_VENDOR_TECHNICA", "PLP Vendor Specific Bus Technica Engineering")
	const_vendor_id = 0xC
	
	-- Create the protocol fields
	local f = VENDOR_STATUS_BUS_PROTO.fields
    -- Buffer overflow
    f.linkstatus = ProtoField.uint8 ("plp_status_bus.vendor.te.linkstatus", _ljust("Link Status", al_f["vendor"]), base.DEC, LINK_STATUS_ENUM)
	
    
    -- Temperature
    f.linkquality = ProtoField.uint8 ("plp_status_bus.vendor.te.linkquality", _ljust("Link Quality", al_f["vendor"]), base.DEC, LINK_QUALITY_ENUM)
    
    -- Linkup Time
	f.linkuptime = ProtoField.uint16 ("plp_status_bus.vendor.te.linkuptime", _ljust("Link Uptime", al_f["vendor"]), base.DEC)
    
    
	local plp_TE_table = DissectorTable.new("plp_vendor_technica_bus", "plp_vendor_technica_bus")

	-- The dissector function
	function VENDOR_STATUS_BUS_PROTO.dissector (buffer, pinfo, tree)
        -- some offsets	
        O_LINK_STATUS = 0
        O_LINK_QUALITY = 1
        O_LINKUP_TIME = 2

		-- Probe-type specific part of the dissector
		if probe_type_val == c_PROBE_TYPE_CM_SERDES_GMSL2_3 then
			table_plp_bus_type_specific_status:try(probe_type_val, buffer, pinfo, tree)  
		else
			-- Default dissector
			-- Adding fields to the tree
			local technica_tree = tree:add (VENDOR_STATUS_BUS_PROTO, buffer())

			-- Link Status
			technica_tree:add(f.linkstatus, buffer:range(O_LINK_STATUS, 1))
			
			-- Link Quality
			technica_tree:add(f.linkquality, buffer:range(O_LINK_QUALITY, 1))
			
			-- Linkup Time
			local linkuptime = buffer:range(O_LINKUP_TIME, 2):uint()
			predefined_linkuptime_value =  LINKUP_TIME_ENUM[linkuptime]
			local linkuptime_text = ""
			if predefined_linkuptime_value ~= nil then
				linkuptime_text = predefined_linkuptime_value
			else
				linkuptime_text = " (ms. linkup detected)"		
			end
			
			linkup_node = technica_tree:add(f.linkuptime, buffer:range(O_LINKUP_TIME, 2))
			linkup_node:append_text(linkuptime_text)     	
		end
	end
	
	plp_table = DissectorTable.get("plp.vendorspecificbus")    
	plp_table:add(const_vendor_id, VENDOR_STATUS_BUS_PROTO)
    --for key,value in pairs (const_probe_id) do 
    --    plp_table:add(value, VENDOR_STATUS_BUS_PROTO)
    --end
    
	
end